#' Averaging the squared distance matrices each calculated from a rarefied OTU table
#' 
#' This function computes a distance matrix for each rarefied OTU table, square the distance matrix (in an element-wise manner), 
#' and then average the squared distance matrices.
#' 
#' @param otu.table the \code{n.obs} by \code{n.otu} matrix of read counts. 
#' @param dist.method method for calculating the distance measure, partial
#' match to all methods supported by \code{vegdist} in the \code{vegan} package. The default is "jaccard". 
#' For more details, see the \code{dist.method} argument in the \code{ldm} function.
#' @param tree the phylogeneic tree. The default is NULL.
#' @param scale.otu.table a logical variable indicating whether to scale the rows of the OTU table. 
#' For count data, this corresponds to dividing by the library size to give relative frequencies. 
#' The default is FALSE.
#' @param n.rarefy number of rarefactions. The default is 100.
#' @param binary the "binary" parameter in \code{vegdist}. The default is TRUE.
#' @param seed a single-value integer seed for the random process of drawing rarefaction replicates. 
#' The seed is user supplied or internally generated. The default is 123.
#' @return a single matrix object
#'   \item{D2.avg}{The average of the squared distance matrices.}

#' @keywords microbiome
#' @author Yi-Juan Hu <yijuan.hu@emory.edu>, Glen A. Satten <gsatten@emory.edu>
#' @export
#' @examples
#' dist.avg.D2 <- avgdist_squared(throat.otu.tab5, dist.method="jaccard", n.rarefy=100)

avgdist.squared = function(otu.table, dist.method="jaccard", tree=NULL, scale.otu.table=FALSE, n.rarefy=100, binary=TRUE, seed=123) {
    
    if (is.null(seed)) {
        seed = sample(1:10^6, 1)
    }
    set.seed(seed)
    
    n.sam = nrow(otu.table)
    D2.avg = matrix(0, n.sam, n.sam)
    
    for (r in 1:n.rarefy) {
        otu.rarefy = Rarefy(otu.table)$otu.tab.rff
        if (binary) otu.rarefy = (otu.rarefy>0)*1
        
        dist <- calculate.dist(dist.method=dist.method, otu.table=otu.rarefy, tree=tree, scale.otu.table=scale.otu.table, binary=binary)
        D2.avg = D2.avg + dist^2
    }
    D2.avg = D2.avg/n.rarefy
    
    return(D2.avg)
    
} # avgdist2


gower = function (d, square=TRUE, center=TRUE) 
{
    
    a <- as.matrix(d)
    
    #--------------------------------------------------------------
    # squaring the matrix 
    #--------------------------------------------------------------
    
    if (square) a <- a^2
    
    #--------------------------------------------------------------
    # centering rows and columns of the (squared) matrix of d
    #--------------------------------------------------------------
    
    if (center) {

        a =  sweep(a, 1, rowMeans(a) )
        a = -sweep(a, 2, colMeans(a) )/2

    }
    
    return(a)
    
}# gower


fdr.Sandev = function(p.otu) {
    
    m = length(p.otu)
    
    p.otu.sort = sort(p.otu)
    n.otu.detected = seq(1, m)
    pi0 = min(1, 2/m*sum(p.otu))
    
    qval.sort = m * pi0 * p.otu.sort / n.otu.detected
    j.min.q = 1
    while (j.min.q < m) {
        min.q = min( qval.sort[j.min.q:m] )
        new.j.min.q = (j.min.q-1) + max( which(qval.sort[j.min.q:m]==min.q) )
        qval.sort[j.min.q:new.j.min.q] = qval.sort[new.j.min.q]
        j.min.q = new.j.min.q+1
    }
    mat = match(p.otu, p.otu.sort)   
    qval.orig = qval.sort[mat]
    results = qval.orig
    return(results)
    
} # fdr.Sandev


calculate.dist <- function(otu.table, tree=NULL, dist.method="bray", 
                           binary=FALSE, rarefy=0, scale.otu.table=TRUE) {
    
    rowsum = rowSums(otu.table)
    if (min(rowsum)==0) {
        warning("There exists sample(s) with zero reads at every OTU!")
    }
    
    rowsum[which(rowsum==0)] = 1
    if (scale.otu.table) freq.table <- t( scale( t(otu.table), center=FALSE, scale=rowsum ) )
    else freq.table <- otu.table
    
    if (grepl(dist.method, "wt-unifrac")) {
        dist <- GUniFrac(otu.table, tree, alpha=c(1))$unifrac[,,"d_1"]
    } else if (grepl(dist.method, "unwt-unifrac")) {
        dist <- GUniFrac(otu.table, tree, alpha=c(1))$unifrac[,,"d_UW"]
    } else if (grepl(dist.method, "hellinger")) {
        dist <- 0.5*dist( x=sqrt(freq.table), method='euclidean')
    } else {
        dist <- vegdist(x=freq.table, method=dist.method, binary=binary)
    }
    
    # if (dist.method==tolower("bray")) {
    #     dist <- 0.5*as.matrix( dist( x=freq.table, method='manhattan') )
    # } else if (dist.method==tolower("Jaccard")) {
    # dist <- vegdist(x=otu.table, method="jaccard", binary=TRUE)
    # }
    
    dist <- as.matrix(dist)
    
    return(dist)
    
} # calculate.dist


#' Adjusting data (distance matrix and OTU table) by covariates
#' 
#' This function produces adjusted distance matrix and OTU table (if provided) 
#' after removing the effects of covariates (e.g., confounders). 
#' Observations with any missing data are removed.
#' 
#' @param formula a symbolic description of the covariate model in the form \code{ ~ model}, 
#' where \code{model} is specified in the same way as for \code{lm} or \code{glm}. For example, 
#' \code{~ a + b} specifies a model with the main effects of covariates \code{a} and \code{b}, and 
#' \code{~ a*b}, equivalently \code{~ a + b + a:b}, specifies a model with the main effects of 
#' \code{a} and \code{b} as well as their interaction.
#' @param data an optional data frame, list or environment (or object coercible 
#' by as.data.frame to a data frame) containing the covariates. 
#' If not found in \code{data}, the covariates are taken from environment (formula), 
#' typically the environment from which \code{adjust.data.by.covariates} is called. 
#' The default is .GlobalEnv.
#' @param otu.table the \code{n.obs} by \code{n.otu} matrix of read counts. 
#' If provided, an adjusted (and column-centered) OTU table at the frequency (i.e., relative abundance) scale 
#' and an adjusted (and columnn-centered) OTU table at the arcsin-root-transformed frequency scale are output. If provided, 
#' it is also used for calculating the distance matrix unless the distance matrix is directly 
#' imported through \code{dist}.
#' The default is NULL.
#' @param tree a phylogenetic tree. Only used for calculating a
#'   phylogenetic-tree-based distance matrix. Not needed if the calculation of
#'   requested distance does not require a phylogenetic tree, or if the distance
#'   matrix is directly imported through \code{dist}. The default is NULL.
#' @param dist.method method for calculating the distance measure, partial
#' match to all methods supported by \code{vegdist} in the \code{vegan} package
#'  (i.e., "manhattan", "euclidean", "canberra", "bray", "kulczynski", "jaccard", "gower", 
#'  "altGower", "morisita", "horn", "mountford", "raup" , "binomial", "chao", "cao", "mahalanobis")
#'   as well as "hellinger" and "wt-unifrac". 
#'   The default is "bray". 
#'   For more details, see the \code{dist.method} argument in the \code{ldm} function.
#' @param binary the "binary" parameter in \code{vegdist}. The default is FALSE.
#' @param dist a distance matrix. Can be either an object of class "dist" or "matrix".
#'   The elements of the distance matrix will be squared and then the matrix will be centered if the default choices 
#'   \code{square.dist=TRUE} and \code{center.dist=TRUE} are used. If \code{dist=NULL}, the distance matrix is 
#'   calculated from the \code{otu.table}, using the value of \code{dist.method} (and \code{tree} if required). 
#'   The default is NULL.
#' @param square.dist a logical variable indicating whether to square the 
#'   distance matrix. The default is TRUE.
#' @param center.dist a logical variable indicating whether to center the 
#'   distance matrix as described by Gower (1966). The default is TRUE.
#' @param scale.otu.table a logical variable indicating whether to scale the rows of the OTU table 
#'   for the frequency scale.  For count data, this corresponds to dividing by the library size to give 
#'   relative frequencies. The default is TRUE. 
#' @param center.otu.table a logical variable indicating whether to center the 
#'   columns of the OTU table. The OTU table should be centered if the distance 
#'   matrix has been centered. Applied to both OTU tables at frequency and transformed scales. The default is TRUE.
#' @param freq.scale.only a logical variable indicating whether to provide adjusted frequency-scale OTU table only 
#' (not adjusted OTU table at the arcsin-root transformed frequency scale). The default is FALSE.
#' @return a list consisting of 
#'   \item{adj.dist}{the (squared/centered) distance matrix
#'   after adjustment of covariates.}
#'   \item{y.freq}{the (column-centered) frequency-scale OTU table after adjustment of covariates.} 
#'   \item{y.tran}{the (column-centered) arcsin-root-transformed 
#'   OTU table after adjustment of covariates.} 

#' @keywords microbiome PCA ordination distance
#' @author Yi-Juan Hu <yijuan.hu@emory.edu>, Glen A. Satten <gsatten@emory.edu>
#' @export
#' @examples
#' adj.data <- adjust.data.by.covariates(formula= ~ Sex + AntibioticUse, data=throat.meta,
#'                                       otu.table=throat.otu.tab5, dist.method="bray")
#'
#' #-------------------------------------------------
#' # Use the adjusted distance matrix for ordination
#' #-------------------------------------------------
#'
#' PCs <- eigen(adj.data$adj.dist, symmetric=TRUE)
#' 
#' color = rep("blue", length(throat.meta$SmokingStatus))
#' w = which(throat.meta$SmokingStatus=="Smoker")
#' color[w] = "red"
#' 
#' plot(PCs$vectors[,1], PCs$vectors[,2], xlab="PC1", ylab="PC2", 
#'      col=color, main="Ordination based on Bray-Curtis distance")
#' legend(x="topleft", legend=c("smokers","non-smokers"), pch=c(21,21), 
#'        col=c("red","blue"), lty=0)
#' ordiellipse(ord=PCs$vectors, groups=factor(throat.meta$SmokingStatus, exclude=c()), 
#'        conf=0.9, col=c("blue", "red"))


adjust.data.by.covariates = function(formula=NULL, data=.GlobalEnv, 
                                     otu.table=NULL, tree=NULL, dist.method="bray", binary=FALSE, dist=NULL, 
                                     square.dist=TRUE, center.dist=TRUE, 
                                     scale.otu.table=TRUE, center.otu.table=TRUE,
                                     freq.scale.only=FALSE) {
    
    #------------------------
    # covariates (e.g., confounders)
    #------------------------
    
    options(na.action=na.pass)
    m1 = model.matrix(object=formula, data=data)
    
    if (!is.null(dist)) {
        dist = as.matrix(dist)
        if (dim(m1)[1] != dim(dist)[1]) stop( 'numbers of observations mismatch between covariates and dist' )
    }
    if (!is.null(otu.table)) {
        # remove zero OTUs
        w = which(colSums(abs(otu.table))>0)
        if (length(w) < ncol(otu.table)) {
            warning(paste(ncol(otu.table)-length(w), 'OTU(s) with zero counts in all samples are removed', sep=" "))
            otu.table = otu.table[,w,drop=FALSE]
        }
        
        if (dim(m1)[1] != dim(otu.table)[1]) 
            otu.table <- t(otu.table)
        if (dim(m1)[1] != dim(otu.table)[1]) stop( 'numbers of observations mismatch between covariates and otu.table' )
    }
    
    if (any(is.na(m1))) {
        w = apply(is.na(m1), 1, any)
        warning(paste(sum(w), 'observation(s) with any missing data are removed', sep=" "))
        
        w = !w
        if (!is.null(dist)) dist = dist[w, w]
        if (!is.null(otu.table)) otu.table = otu.table[w,]
        m1 = m1[w,]
    }
    
    center.m1 = TRUE
    if (center.m1) m1 = scale( m1, center=TRUE, scale=FALSE )
    
    
    #------------------------
    # dist matrix
    #------------------------
    
    if (is.null(dist) & is.null(otu.table)) {
        stop( 'must specify one of dist and otu.table' )
    }
    
    if (!is.null(otu.table) & !is.null(dist)) {
        if (dim(otu.table)[1] != dim(dist)[1]) stop( 'numbers of observations mismatch between otu.table and dist' )
    }
    
    if (is.null(dist)) {
        dist <- calculate.dist(dist.method=dist.method, otu.table=otu.table, tree=tree, scale.otu.table=scale.otu.table, binary=binary)
    }
    
    d.gower <- gower(d=dist, square=square.dist, center=center.dist)
    
    
    #---------------------
    # calculate d.resid
    #---------------------
    
    tol.d=10^-8
    svd.m1 = svd(m1)
    use = (svd.m1$d>tol.d)
    
    hat.matrix = svd.m1$u[, use] %*% t( svd.m1$u[, use] )
    hat.matrix.bar = diag(dim(d.gower)[1]) - hat.matrix
    
    d.resid = hat.matrix.bar %*% d.gower
    d.resid = d.resid %*% hat.matrix.bar
    
    #---------------------
    # calculate adj.otu.table
    #---------------------
    
    y.freq = NULL
    y.tran = NULL
    
    if (!is.null(otu.table)) {
        
        rowsum = rowSums(otu.table)
        if (min(rowsum)==0) {
            warning("There exists sample(s) with zero reads at every OTU!")
        }
        
        # freq
        if (scale.otu.table) {
            rowsum[which(rowsum==0)] = 1
            freq.table <- t( scale( t(otu.table), center=FALSE, scale=rowsum ) )
        } else {
            freq.table <- otu.table
        }
        y.freq <- scale( freq.table, center=center.otu.table, scale=FALSE )
        
        y.tran <- NULL
        if (!freq.scale.only) {
            # arcsin
            theta <- asin(sqrt(freq.table))
            y.tran <- scale( theta, center=center.otu.table, scale=FALSE)
        }
        
        # # check discordant centering (turn off)
        # max.center.gower <- max(abs(rowMeans(d.gower)))
        # max.center.yfreq  <- max(abs(colMeans(y.freq)))
        # if ( (max.center.gower - 10^-6) * (max.center.yfreq - 10^-6) < 0) {
        #     stop( 'discordant centering of the OTU table and distance matrix' )
        # }
        
        # x.model
        x.model = svd.m1$u[, use]
        
        # adj.otu.table
        x1.tilda.freq = t(x.model) %*% y.freq
        x1.tilda.freq = x.model %*% x1.tilda.freq
        y.freq = y.freq - x1.tilda.freq
        
        if (!freq.scale.only) {
            x1.tilda.tran = t(x.model) %*% y.tran
            x1.tilda.tran = x.model %*% x1.tilda.tran
            y.tran = y.tran - x1.tilda.tran
        }
    }
    
    res <- list(y.freq=y.freq,
                y.tran=y.tran,
                adj.dist=d.resid)
    
    return(res)
    
} # adjust.data.by.covariates


#' Testing hypotheses using a linear decomposition model (LDM)
#' 
#' This function allows you to 
#' 1. simultaneously test the global association with the overall  
#' microbiome composition and individual OTU associations to give coherent 
#' results;
#' 2. test hypotheses based on data at both the frequency (i.e., relative abundance) and arcsine-root-transformed frequency scales, 
#' and perform an ``omnibus" test that combines results from analyses conducted on the two scales;
#' 3. test presence-absence associations based on infinite number of rarefaction replicates;
#' 4. handle complex design features such as 
#' confounders, interactions, and clustered data (with between- and within-cluster covariates).
#' 
#' The formula has the form 
#' 
#' \code{otu.table ~ (first set of covariates) + (second set of covariates)
#' ... + (last set of covariates)} 
#' 
#' or 
#' 
#' \code{otu.table | confounders ~ (first set of covariates) + (second set of covariates)
#' ... + (last set of covariates)} 
#' 
#' where \code{otu.table} is
#' the OTU table with rows for samples and columns for OTUs and each set of 
#' covariates are enclosed in parentheses. The covariates in each submodel (set of covariates) are tested jointly,
#' after projecting off terms in submodels that appear earlier in the model.
#' 
#' For example, given OTU table \code{y} and a data frame \code{metadata} that contains 4 covariates, 
#' \code{a}, \code{b}, \code{c} and \code{d},  
#' some valid formulas would be:
#' 
#' \code{y ~ a + b + c + d} ### no confounders, 4 submodels (i.e., sets of covariates)
#' 
#' \code{y ~ (a+b) + (c+d)} ### no confounders, 2 submodels each having 
#' 2 covariates
#' 
#' \code{y | b ~ (a+c) + d} ### \code{b} is a confounder, submodel 1 is 
#' \code{(a+c)}, and submodel 2 is \code{d}
#' 
#' \code{y | b+c ~ a*d}     ### there are 2 confounders \code{b} 
#' and \code{c}; there is 1 submodel consisting of the three terms \code{a}, \code{d}, and \code{a:d} (interaction). 
#' This example is equivalent to \code{y | b+c ~ (a+d+a:d)}
#' 
#' \code{y | as.factor(b) ~ (a+d) + a:d}  ### the confounder 
#' \code{b} will be treated as a factor variable, submodel 1 will have the main 
#' effects \code{a} and \code{d}, and submodel 2 will have only the interaction 
#' between \code{a} and \code{d}
#' 
#' \code{y | as.factor(b) ~ (a) + (d) + (a:d)} ### there are 3 submodels \code{a}, \code{d}, and \code{a:d}.
#' Putting paratheses around a single variable is allowed but not necessary.
#'
#' Submodels that combine character and numeric values are allowed; character-valued variables are coerced into factor 
#' variables.  Confounders are distinguished from other covariates as test statistics are not calculated for confounders
#' (which are included for scientific reasons, not by virtue of significance test results); 
#' consequently they also do not contribute to stopping criteria.  If tests of confounders are desired, confounders should
#' put on the right hand side of the formula as the first submodel.
#' 
#' LDM uses two sequential stopping criteria. For the global test, LDM uses the 
#' stopping rule of Besag and Clifford (1991), which stops permutation when a 
#' pre-specified minimum number (default=100) of rejections (i.e., the permutation 
#' statistic exceeded the observed test statistic) has been reached. For the 
#' OTU-specific tests, LDM uses the stopping rule of Sandve et al. (2011), 
#' which stops permutation when every OTU test has either reached the pre-specified 
#' number (default=100) of rejections or yielded a q-value that is below the 
#' nominal FDR level (default=0.1). As a convention, we call a test "stopped"
#' if the corresponding stopping criterion has been satisfied. Although all tests 
#' are always terminated if a pre-specified maximum number (see description of \code{n.perm.max} in Arguments list) of 
#' permutations have been generated, some tests may not have "stopped".  This typically occurs when
#' the relevant p-value is small or near the cutoff for inclusion in a list of significant findings; 
#' for global tests meeting the stopping criterion is not critical, but 
#' caution is advised when interpreting OTU-level tests that have not stopped as additional OTUs may be found 
#' with a larger number of permutations.
#' 
#' 
#' @param formula a symbolic description of the 
#'   model to be fitted. The details of model specification are given under 
#'   "Details".
#' @param data an optional data frame, list or environment (or object coercible 
#' by as.data.frame to a data frame) containing the covariates of interest and 
#' confounding covariates. 
#' If not found in \code{data}, the covariates are taken from environment(formula), 
#' typically the environment from which \code{ldm} is called. The default is .GlobalEnv.
#' @param tree a phylogenetic tree. Only used for calculating a 
#'   phylogenetic-tree-based distance matrix. Not needed if the calculation of 
#'   the requested distance does not involve a phylogenetic tree, or if the 
#'   distance matrix is directly imported through \code{dist}.
#' @param dist.method method for calculating the distance measure, partial
#' match to all methods supported by \code{vegdist} in the \code{vegan} package
#'  (i.e., "manhattan", "euclidean", "canberra", "bray", "kulczynski", "jaccard", 
#'  "gower", "altGower", "morisita", "horn", "mountford", "raup" , "binomial", 
#'  "chao", "cao", "mahalanobis") as well as "hellinger" and "wt-unifrac". 
#'  The Hellinger distance measure (\code{dist.method="hellinger"}) takes the form
#'  \code{0.5*E}, where E is the Euclidean distance between the square-root-transformed 
#'  frequency data. The weighted UniFrac distance (\code{dist.method="wt-unifrac"}) 
#'  is calculated by interally calling \code{GUniFrac} in the \code{GUniFrac} package.
#'   Not used when anything other than \code{dist=NULL} is specified for \code{dist}.
#'   The default is "bray".
#' @param dist a distance matrix. Can be an object of class either "dist" or "matrix".
#'   The elements of the distance matrix will be squared and then the matrix will be centered if the default choices 
#'   \code{square.dist=TRUE} and \code{center.dist=TRUE} are used. If \code{dist=NULL}, the distance matrix is 
#'   calculated from the \code{otu.table}, using the value of \code{dist.method} (and \code{tree} if required). 
#'   The default is NULL.
#' @param cluster.id character or factor variable that identifies clusters. The default value
#'   cluster.id=NULL if the observations are not clustered (i.e., are independent).
#' @param strata a character or factor variable that defines strata (groups), within which to constrain permutations. 
#'   The default is NULL.
#' @param how a permutation control list, for users who want to specify their own call to the \code{how} function from the \code{permute} package.  
#'   The default is NULL.
#' @param perm.within.type a character string that takes values "free", "none", "series", or "grid".  
#'   The default is "free" (for random permutations).
#' @param perm.between.type a character string that takes values "free", "none", or "series".  
#'   The default is "none".
#' @param perm.within.nrow a positive integer, only used if perm.within.type="grid". 
#'   The default is 0.  See documentation for permute package for additional details.
#' @param perm.within.ncol a positive integer, only used if perm.within.type="grid". 
#'   The default is 0.  See documentation for permute package for additional details.
#' @param n.perm.max the maximum number of permutations. The default is NULL, in which case a maximum of
#'   5000 permutations are used for the global test and a maximum of \code{n.otu} * \code{n.rej.stop} * (1/\code{fdr.nominal}) 
#'   are used for the OTU test, where \code{n.otu} is the number of OTUs.  If a numeric value for \code{n.otu} is specified, 
#'   this value is used for both global and OTU-level tests.
#' @param n.rej.stop the minimum number of rejections (i.e., the permutation 
#'   statistic exceeds the observed statistic) to obtain before stopping. The 
#'   default is 100.
#' @param seed a user-supplied integer seed for the random number generator in the 
#'   permutation procedure. The default is NULL; with the default value, an integer seed will be 
#'   generated internally and randomly. In either case, the integer seed will be stored
#'   in the output object in case 
#'   the user wants to reproduce the permutation replicates.
#' @param test.global a logical value indicating whether to perform the global 
#'   test. The default is TRUE.
#' @param test.otu a logical value indicating whether to perform the 
#'   OTU-specific tests. The default is TRUE.
#' @param fdr.nominal the nominal FDR value. The default is 0.1.
#' @param square.dist a logical variable indicating whether to square the 
#'   distance matrix. The default is TRUE.
#' @param center.dist a logical variable indicating whether to center the 
#'   distance matrix as described by Gower (1966). The default is TRUE.
#' @param scale.otu.table a logical variable indicating whether to scale the rows of the OTU table.  For count 
#'   data, this corresponds to dividing by the library size to give frequencies (i.e., relative abundances).  Does not affect the tran scale.  
#'   The default is TRUE. 
#' @param center.otu.table a logical variable indicating whether to center the 
#'   columns of the OTU table. The OTU table should be centered if the distance 
#'   matrix has been centered. Applied to both the frequency and transformed scales.  The default is TRUE.
#' @param freq.scale.only a logical variable indicating whether to perform analysis of the frequency-scale data only 
#' (not the arcsin-root transformed frequency data and the omnibus test). The default is FALSE.
#' @param binary a logical value indicating whether to perform presence-absence
#'   analysis. The default is FALSE (analyzing relative abundance data).
#' @param n.rarefy an integer-valued number of rarefactions. The value "all" is also allowed, 
#' and requests the LDM-A method that essentially aggregate information from all rarefactions.
#'  The default is 0 (no rarefaction).
#' @return a list consisting of 
#'   \item{x}{the (orthonormal) design matrix X as defined in Hu and Satten (2020)} 
#'   \item{dist}{the (squared/centered) distance matrix} 
#'   \item{mean.freq}{the mean relative abundance of OTUs (the column means of the frequency-scale OTU table)} 
#'   \item{y.freq}{the frequency-scale OTU table, scaled and centered if so specified} 
#'   \item{d.freq}{a vector of the non-negative diagonal elements of \code{D} that satisfies
#'   \code{x^T y.freq = D v^T}}
#'   \item{v.freq}{the v matrix with unit columns that satisfies
#'   \code{x^T y.freq = D v^T}}
#'   \item{y.tran}{the (column-centered) arcsin-root-transformed 
#'   OTU table} 
#'   \item{d.tran}{a vector of the non-negative diagonal elements of \code{D} that satisfies
#'   \code{x^T y.tran = D v^T}}
#'   \item{v.tran}{the v matrix with unit columns that satisfies
#'   \code{x^T y.tran = D v^T}}
#'   \item{low}{a vector of lower indices for confounders (if there is any) and submodels}
#'   \item{up}{a vector of upper indices for confounders (if there is any) and submodels}
#'   \item{beta}{a matrix of effect sizes of every trait on every OTU}
#'   \item{phi}{a matrix of probabilities that the rarefied count of an OTU in a sample is non-zero}
#'   \item{VE.global.freq.confounders}{Variance explained (VE) by confounders, based on the frequency-scale data}
#'   \item{VE.global.freq.submodels}{VE by each submodel, based on the frequency-scale data}
#'   \item{VE.global.freq.residuals}{VE by each component in the residual distance, based on the frequency-scale data}
#'   \item{VE.otu.freq.confounders}{Contribution of each OTU to VE by confounders, based on the frequency-scale data}
#'   \item{VE.otu.freq.submodel}{Contribution of each OTU to VE by each submodel, based on the frequency-scale data}
#'   \item{VE.global.tran.confounders}{VE by confounders, based on 
#'   the arcsin-root-transformed frequency data}
#'   \item{VE.global.tran.submodels}{VE by each submodel, based on 
#'   the arcsin-root-transformed frequency data}
#'   \item{VE.global.tran.residuals}{VE by each component in the residual distance, based on 
#'   the arcsin-root-transformed frequency data}
#'   \item{VE.otu.tran.confounders}{Contribution of each OTU to VE by confounders, based on 
#'   the arcsin-root-transformed frequency data}
#'   \item{VE.otu.tran.submodels}{Contribution of each OTU to VE by each submodel, based on 
#'   the arcsin-root-transformed frequency data}
#'   \item{VE.df.confounders}{Degree of freedom (i.e., number of components) associated with the VE for confounders}
#'   \item{VE.df.submodels}{Degree of freedom (i.e., number of components) associated with the VE for each submodel}
#'   \item{F.global.freq}{F statistics for testing each submodel, based on
#'   the frequency-scale data} 
#'   \item{F.global.tran}{F statistics for testing each submodel, based on 
#'   the arcsin-root-transformed frequency data} 
#'   \item{F.otu.freq}{F statistics for testing each OTU for each submodel, based on the frequency-scale data} 
#'   \item{F.otu.tran}{F statistics for testing each OTU for each submodel, based on the arcsin-root-transformed data} 
#'   \item{p.global.freq}{p-values for the global test of each set of covariates
#'   based on the frequency-scale data} 
#'   \item{p.global.tran}{p-values for the global test of each set of covariates
#'   based on the arcsin-root-transformed frequency data} 
#'   \item{p.global.omni}{p-values for the global test of each set of covariates 
#'   based on the omnibus statistics, which are the minima of the p-values obtained 
#'   from the frequency scale and the arcsin-root-transformed frequency data 
#'   as the final test statistics, and use the corresponding minima from the 
#'   permuted data to simulate the null distributions} 
#'   \item{p.otu.freq}{p-values for the OTU-specific tests based on the 
#'   frequency scale data} 
#'   \item{p.otu.tran}{p-values for the OTU-specific tests based on the 
#'   arcsin-root-transformed frequency data} 
#'   \item{p.otu.omni}{p-values for the OTU-specific tests based on the 
#'   omnibus statistics} 
#'   \item{q.otu.freq}{q-values (i.e., FDR-adjusted p-values) 
#'   for the OTU-specific tests based on the frequency scale data} 
#'   \item{q.otu.tran}{q-values for the OTU-specific tests based on 
#'   the arcsin-root-transformed frequency data} 
#'   \item{q.otu.omni}{q-values for the OTU-specific tests based on the 
#'   omnibus statistics} 
#'   \item{detected.otu.freq}{detected OTUs (whose names are found in the column names of the OTU table) at the nominal FDR, based on the frequency scale data} 
#'   \item{n.detected.otu.freq}{number of detected OTUs in \code{detected.otu.freq}} 
#'   \item{detected.otu.tran}{detected OTUs based on the arcsin-root-transformed frequency data} 
#'   \item{n.detected.otu.tran}{number of detected OTUs in \code{detected.otu.tran}} 
#'   \item{detected.otu.omni}{detected OTU based on the 
#'   omnibus statistics} 
#'   \item{n.detected.otu.omni}{number of detected OTUs in \code{detected.otu.omni}} 
#'   \item{p.global.pa}{p-values for the global test of each set of covariates
#'   based on the presence-absence data} 
#'   \item{p.otu.pa}{p-values for the OTU-specific tests based on the 
#'   presence-absence data} 
#'   \item{q.otu.pa}{q-values (i.e., FDR-adjusted p-values) 
#'   for the OTU-specific tests based on the presence-absence data} 
#'   \item{detected.otu.pa}{detected OTUs based on the presence-absence data} 
#'   \item{n.detected.otu.pa}{number of detected OTUs in \code{detected.otu.pa}} 
#'   \item{n.perm.completed}{number of permutations completed} 
#'   \item{global.tests.stopped}{a logical value indicating whether the 
#'   stopping criterion has been met by all global tests} 
#'   \item{otu.tests.stopped}{a logical value indicating whether the 
#'   stopping criterion has been met by all OTU-specific tests}
#'   \item{seed}{the seed that is user supplied or internally generated, stored in case 
#'   the user wants to reproduce the permutation replicates}
#' @keywords microbiome
#' @author Yi-Juan Hu <yijuan.hu@emory.edu>, Glen A. Satten <gsatten@emory.edu>
#' @export
#' @references Hu YJ, Satten GA. (2020) Testing hypotheses about the microbiome using the linear decomposition model (LDM) 
#'   Bioinformatics, 36(14), 4106-4115.
#' @examples
#' 
#'#-----------------------------------------------
#'# Fitting the LDM model only, without testing
#'#-----------------------------------------------
#'fit <- ldm(formula=throat.otu.tab5 | (Sex+AntibioticUse) ~ SmokingStatus+PackYears, 
#'           data=throat.meta, 
#'           n.perm.max=0)      # parameter for fitting the LDM without testing
#'
#'#-----------------------------------------------
#'# Testing relative-abundance associations
#'#-----------------------------------------------
#'res.ldm <- ldm(formula=throat.otu.tab5 | (Sex+AntibioticUse) ~ SmokingStatus+PackYears, 
#'               data=throat.meta, seed=67817, fdr.nominal=0.1) 
#' 
#'#-----------------------------------------------
#'# Testing presence-absence associations: LDM-A (recommended)
#'#-----------------------------------------------
#'res.ldmA <- ldm(formula=throat.otu.tab5 | (Sex+AntibioticUse) ~ SmokingStatus+PackYears, 
#'                data=throat.meta, seed=67817, 
#'                n.rarefy="all") # parameter for requesting LDM-A
#'                
#'#-----------------------------------------------
#'# Testing presence-absence associations: LDM-F(5)
#'#-----------------------------------------------
#'res.ldmF <- ldm(formula=throat.otu.tab5 | (Sex+AntibioticUse) ~ SmokingStatus+PackYears, 
#'                data=throat.meta, seed=67817, 
#'                binary=TRUE, n.rarefy=5) # parameters for requesting LDM-F(5)
#'                
#'#-------------------------------------------------------------------------
#'# Testing associations with between-cluster covariates in clustered data
#'#-------------------------------------------------------------------------
#'res.ldm.repeated <- ldm(formula=sim.otu.tab5 | X.between ~ Y.between, 
#'                        data=sim.meta, seed=34794,
#'                        cluster.id=ID,                # parameters for requesting analysis of  
#'                        perm.within.type="none", perm.between.type="free") # repeated samples
#'                        
#'#-------------------------------------------------------------------------
#'# Testing associations with within-cluster covariates in matched-set data
#'#-------------------------------------------------------------------------
#'res.ldm.matched <- ldm(formula=sim.otu.tab5 | as.factor(ID) + X.within ~ Y.within, 
#'                       data=sim.meta, seed=34794,
#'                       cluster.id=ID,            # parameters for requesting analysis of  
#'                       perm.within.type="free", perm.between.type="none") # matched sets     



ldm = function( formula, data=.GlobalEnv, tree=NULL, dist.method="bray", dist=NULL, 
                     cluster.id=NULL, strata=NULL, how=NULL,
                     perm.within.type="free", perm.between.type="none",
                     perm.within.ncol=0, perm.within.nrow=0,
                     n.perm.max=NULL, n.rej.stop=100, seed=NULL, 
                     test.global=TRUE, test.otu=TRUE, fdr.nominal=0.1,
                     square.dist=TRUE, center.dist=TRUE, 
                     scale.otu.table=TRUE, center.otu.table=TRUE,
                     freq.scale.only=FALSE, binary=FALSE, n.rarefy=0) {  
    
    #------------------------
    # form.call
    #------------------------
    options(na.action=na.omit) # fixed a bug here
    object=formula
    #
    #   extract cluster.id from dataframe
    #
    cl=match.call()
    mf=match.call(expand.dots=FALSE)
    m=match( x='cluster.id', table=names(mf) )
    mf.string=as.character( mf[c(1L,m)] )
    cluster.name=mf.string[2]
    if (cluster.name=='NULL') {
        cluster.id=NULL
    } else {   
        loc.dollar=tail( gregexpr('\\$', cluster.name)[[1]] , n=1 )
        if (loc.dollar<0)  {
            cluster.id=getElement(data,cluster.name)
            if( is.null(cluster.id) ) cluster.id=get(cluster.name)
        } else {   
            df.name=get( substr(cluster.name, start=1, stop=loc.dollar-1) )
            var.name=substr(cluster.name, start=loc.dollar+1, stop=nchar(cluster.name))            
            cluster.id= getElement(df.name,var.name) 
        }
    }
    #        
    #   extract model from formula    
    #    
    obj=toString(object)
    obj=gsub('\\s','',obj)
    prefix=' ~ + 0 + '
    loc.comma=gregexpr(',',obj)[[1]]
    start.terms=loc.comma[2]
    terms=substr(obj,start=start.terms+1, stop=nchar(obj))
    #
    #   find n.obs and full set of rownames
    #   
    if (class(data)=='data.frame') {
        row.names=rownames(data)
        n.obs=length(row.names)
    } else {   
        df=model.frame( paste('~',terms) , na.action=na.pass )
        row.names=rownames(df)
        n.obs=length(row.names)
    }
    #
    #   check for missing values in cluster.id
    #        
    
    if (is.null(cluster.id)) {
        use.rows=row.names
    } else {   
        use=!is.na(cluster.id)
        use.rows=row.names[use]
    }
    #
    #   check for and extract confounders
    #
    model=list()
    j=1
    loc.bar=regexpr('\\|',obj)[1]
    loc.minus=regexpr('-',obj)[1]
    loc.delim=max( loc.bar, loc.minus)
    if (loc.delim>0) {
        end.confound=loc.comma[2]
        c=substr(obj,start=loc.delim+1, stop=end.confound-1)
        conf=model.matrix( as.formula( paste(prefix,c) ), data=data ) 
        model[[j]]=model.matrix( as.formula( paste(prefix,c) ), data=data ) 
        #       use.rows=intersect( use.rows, rownames(conf) )
        use.rows=rownames(model[[1]]) 
        j=j+1
    } else {
        conf=NULL
    }     
    #
    #   extract model terms
    #
    #   j=1
    continue=TRUE
    while (continue) {
        if (substr(terms,1,1)=='(') {
            stop=regexpr(')\\+',terms)[1]
        } else {
            stop=regexpr('\\+',terms)[1] - 1
        }          
        
        if (stop<=0) stop=nchar(terms) 
        m=substr(terms, start=1, stop=stop)
        model[[j]]=model.matrix( as.formula( paste(prefix,m) ) , data=data)
        use.rows=intersect( use.rows, rownames(model[[j]]) )
        #        if (j==1) {
        #            use.rows=rownames(model[[1]])
        #            }
        #        else {
        #            use.rows=intersect( use.rows, rownames(model[[j]]) )
        #            }         
        if (stop+2<=nchar(terms)) {
            terms=substr(terms, start=stop+2, stop=nchar(terms))
            j=j+1
        } else {
            continue=FALSE
        }             
    }   
    n.model=j    
    #
    #  extract OTU table
    #      
    if (is.null(conf)) loc.delim=loc.comma[2]
    otu.name=substr(obj, start=loc.comma[1]+1, stop=loc.delim-1)
    #   loc.dollar=regexpr('\\$', otu.name)[1]
    loc.dollar=tail( gregexpr('\\$', otu.name)[[1]] , n=1 )
    if (loc.dollar<0)  {
        if (class(data)=='data.frame') {
            otu.table=getElement(data, otu.name)
            if (is.null(otu.table)) otu.table= get(otu.name) 
            otu.table=as.matrix(otu.table)
        } else {
            otu.table=as.matrix( get(otu.name) )
        }
    } else {
        df.name=get( substr(otu.name, start=1, stop=loc.dollar-1) )
        var.name=substr(otu.name, start=loc.dollar+1, stop=nchar(otu.name))
        otu.table=as.matrix( getElement(df.name,var.name) )
    }        
    #    if (is.null(otu.table)) otu.table=as.matrix( getElement(.GlobalEnv,otu.name) )
    if ( nrow(otu.table) != n.obs ) {
        if (ncol(otu.table)==n.obs ) {
            otu.table=t(otu.table)
        } else {   
            print('warning: OTU table and covariates have different number of observations')
            return
        }
    }   
    
    if (!is.null(dist)) {
        dist <- as.matrix(dist)
        if (dim(otu.table)[1] != dim(dist)[1]) stop( 'numbers of observations mismatch between the OTU table and dist' )
    }
    
    #
    #   remove rows having NA 
    #    
    for (j in 1:n.model) {
        keep =  rownames( model[[j]] ) %in% use.rows
        model[[j]]=model[[j]][keep,,drop=FALSE]
    }
    if (!is.null(conf)) {
        keep =  rownames(conf) %in% use.rows 
        conf=conf[keep,,drop=FALSE]
    }
    keep=row.names %in% use.rows    
    otu.table=otu.table[keep,,drop=FALSE]    
    if (!is.null(dist)) dist=dist[keep,keep]
    if (!is.null(cluster.id)) cluster.id=cluster.id[keep]
    
    # transpose
    if (dim(model[[1]])[1] != dim(otu.table)[1]) 
        otu.table <- t(otu.table)
    if (dim(model[[1]])[1] != dim(otu.table)[1]) stop( 'numbers of observations mismatch between covariates and the OTU table' )
    
    # OTU names
    if (is.null(colnames(otu.table))) { 
        colnames(otu.table) = 1:ncol(otu.table)
    }
    
    # remove zero OTUs
    w = which(colSums(abs(otu.table))>0)
    if (length(w) < ncol(otu.table)) {
        warning(paste(ncol(otu.table)-length(w), 'OTU(s) with zero counts in all samples are removed', sep=" "))
        otu.table = otu.table[,w,drop=FALSE]
    }
    
    
    rowsum = rowSums(otu.table)
    if (min(rowsum)==0) {
        warning("There exists sample(s) with zero reads at every OTU!")
    }
    
    #------------------------
    # setup permutation
    #------------------------
    
    if (class(how)=='how') {
        CTRL=how                   # user-provided how list
    } else {
        if (is.null(cluster.id)) {
            if (is.null(perm.within.type) & is.null(perm.between.type)) {
                # default when no unclustered data has no type specified is 'free'
                perm.within.type='free'    
            }
            if (is.null(strata)) {
                # setup for unclustered permutation
                CTRL = how( within=Within(type=perm.within.type, 
                                          nrow=perm.within.nrow, 
                                          ncol=perm.within.ncol))  
            } else {
                # setup for unclustered, stratified permutation
                strata=as.factor(strata)
                CTRL = how( blocks=strata, within=Within(type=perm.within.type, 
                                                         nrow=perm.within.nrow, 
                                                         ncol=perm.within.ncol))  
            }    
        } else {        
            cluster.id=as.factor(cluster.id)
            if (is.null(strata)) {            
                #  clustered but unstratified data
                CTRL = how( plots=Plots(cluster.id, type=perm.between.type ), 
                            within=Within(type=perm.within.type, 
                                          nrow=perm.within.nrow, 
                                          ncol=perm.within.ncol))
            } else {
                #   clustered and stratified data
                strata=as.factor(strata)             
                CTRL = how( blocks=strata, 
                            plots=Plots(cluster.id, type=perm.between.type ), 
                            within=Within(type=perm.within.type, 
                                          nrow=perm.within.nrow, 
                                          ncol=perm.within.ncol))
            }
        }
    }    
    
    
    #------------------------
    # decidinng methods
    #------------------------
    
    all_rarefy = (tolower(n.rarefy)=="all")
    no_rarefy = (n.rarefy==0)
    if (no_rarefy | all_rarefy) n.rarefy=1
    
    if (all_rarefy) {
        scale.otu.table = FALSE
        center.otu.table = FALSE
        center.dist = FALSE
        freq.scale.only=TRUE
        binary=TRUE
    } 
    
    if (binary) {
        scale.otu.table=FALSE
        freq.scale.only=TRUE
    }
    
    #------------------------
    # setup model
    #------------------------
    
    adjust.for.confounders = !is.null(conf)
    
    n.obs = dim(model[[1]])[1]
    n.otu = ncol(otu.table)
    n.var = length(model)
    
    if (all_rarefy) {
        if (adjust.for.confounders) {
            model[[1]] = cbind(rep(1, n.obs), model[[1]])
        } else {
            adjust.for.confounders = TRUE
            for (i in n.var:1) {
                model[[i+1]] = model[[i]]
            }
            model[[1]] = matrix(1, nrow=n.obs, ncol=1)
        }
    }    
    
    n.var = length(model)
    n.var1 = n.var - as.numeric(adjust.for.confounders)
    
    center.vars=center.otu.table
    
    index = rep(0, n.var)
    
    for (i in 1:n.var) {
        m.i = model[[i]]
        if (center.vars) m.i = scale( m.i, center=TRUE, scale=FALSE )
        
        if (i==1) {
            m = m.i
            index[i] = dim(m.i)[2] 
        } else {
            m = cbind(m, m.i)   
            index[i] = index[i-1] + dim(m.i)[2]    
        }
        
    }

    
    #---------------------
    # rarefaction or not?
    #---------------------
    
    if (is.null(seed)) {
        seed = sample(1:10^6, 1)
    }
    set.seed(seed)
    

    if (!all_rarefy) {
        ss.tot.freq = array(NA, dim=c(n.var1, n.otu, n.rarefy))
        resid.freq = array(NA, dim=c(n.obs, n.otu, n.var1, n.rarefy))
        ss.tot.tran = NULL
        resid.tran = NULL
        if (!freq.scale.only) {
            ss.tot.tran = array(NA, dim=c(n.var1, n.otu, n.rarefy))
            resid.tran = array(NA, dim=c(n.obs, n.otu, n.var1, n.rarefy))
        }
    
        for (r in 1:n.rarefy) {
            
            if (!no_rarefy) {
                otu.rarefy= Rarefy(otu.table)$otu.tab.rff
                if (binary) otu.rarefy = (otu.rarefy>0)*1
            } else {
                if (binary) otu.rarefy = (otu.table>0)*1
                else otu.rarefy = otu.table
            }
            
            #------------------------
            # dist matrix
            #------------------------
            
            if (is.null(dist)) {
                if (ncol(otu.rarefy)==1) {
                    dist <- diag(nrow(otu.rarefy))
                } else {
                    dist <- calculate.dist(dist.method=dist.method, otu.table=otu.rarefy, tree=tree, scale.otu.table=scale.otu.table, binary=binary)
                }
            }
            d.gower <- gower(d=dist, square=square.dist, center=center.dist)
            
            #------------------------
            # data matrix y.freq, y.tran
            #------------------------
            
            if (scale.otu.table) {
                rowsum = rowSums(otu.rarefy)
                rowsum[which(rowsum==0)] = 1
                freq.table <- t( scale( t(otu.rarefy), center=FALSE, scale=rowsum ) )
            } else {
                freq.table <- otu.rarefy
            }
            mean.freq <- colMeans(freq.table)
            y.freq <- scale( freq.table, center=center.otu.table, scale=FALSE )
    
            y.tran <- NULL
            if (!freq.scale.only) {
                theta <- asin(sqrt(freq.table))
                y.tran <- scale( theta, center=center.otu.table, scale=FALSE)
            }
            
            if (r==1) {
                max.center.gower <- max(abs(rowMeans(d.gower)))
                max.center.yfreq  <- max(abs(colMeans(y.freq)))
                if ( (max.center.gower - 10^-6) * (max.center.yfreq - 10^-6) < 0) {
                    stop( 'discordant centering of the OTU table and distance matrix' )
                }
            }
            
            #---------------------
            # model fitting
            #---------------------
            
            if (all_rarefy) {
                fit.ldm = calculate.x.and.resid.allrarefy( y=otu.table, # = otu.rarefy = y.freq 
                                                        index=index, m=m, adjust.for.confounders=adjust.for.confounders)  
            } else {
                fit.ldm = calculate.x.and.resid( d.gower=d.gower, y.freq=y.freq, y.tran=y.tran, 
                                             index=index, m=m, adjust.for.confounders=adjust.for.confounders)  
            }
            
            ss.tot.freq[,,r] = fit.ldm$ss.tot.freq
            resid.freq[,,,r] = fit.ldm$resid.freq
            if (!freq.scale.only) {
                ss.tot.tran[,,r] = fit.ldm$ss.tot.tran
                resid.tran[,,,r] = fit.ldm$resid.tran
            }
            
            if (r==1) {
                x = fit.ldm$x
                low = fit.ldm$low
                up = fit.ldm$up
        
                ndf = fit.ldm$ndf
            }
            
        }# rarefaction
        
        
        #---------------------
        # observed statistic
        #---------------------
        
        ldm.obs.freq = ldm.stat(x=x, low=low, up=up, resid=resid.freq, ss.tot=ss.tot.freq, adjust.for.confounders=adjust.for.confounders)
        ldm.obs.tran = NULL
        if (!freq.scale.only) ldm.obs.tran = ldm.stat(x=x, low=low, up=up, resid=resid.tran, ss.tot=ss.tot.tran, adjust.for.confounders=adjust.for.confounders)
    
    } # if (!all_rarefy)
    
    else { # if (all_raerfy)
        
        d.gower = NULL
        y.freq = NULL
        y.tran = NULL
        
        #---------------------
        # model fitting
        #---------------------
        
        fit.ldm = calculate.x.and.resid.allrarefy( y=otu.table, 
                                                index=index, m=m, adjust.for.confounders=adjust.for.confounders)  
        
        #---------------------
        # observed statistic
        #---------------------
        
        ldm.obs.freq = ldm.stat.allrarefy(x=fit.ldm$x, low=fit.ldm$low, up=fit.ldm$up, 
                                       resid=fit.ldm$resid, ss.tot=fit.ldm$ss.tot, 
                                       P.resid=fit.ldm$P.resid, ss.tot.1=fit.ldm$ss.tot.1, 
                                       phi_1phi=fit.ldm$phi_1phi,
                                       adjust.for.confounders=adjust.for.confounders)
        
        ldm.obs.tran = NULL
    }  # if (all_raerfy)
    
    p.global.freq = NULL
    p.global.tran = NULL
    p.global.omni = NULL
    
    p.otu.freq = NULL
    p.otu.tran = NULL
    p.otu.omni = NULL
    
    q.otu.freq = NULL
    q.otu.tran = NULL
    q.otu.omni = NULL
    
    n.perm.completed = NULL
    n.global.perm.completed = NULL
    n.otu.perm.completed = NULL
    
    global.tests.stopped = NULL
    otu.tests.stopped    = NULL
    
    if (is.null(n.perm.max)) {
        n.global.perm.max = ifelse(test.global, 5000, NA)
        n.otu.perm.max = ifelse(test.otu, n.otu * n.rej.stop * (1/fdr.nominal), NA)
        n.perm.max = max(n.global.perm.max, n.otu.perm.max, na.rm=TRUE)
    } else {
        n.global.perm.max = ifelse(test.global, n.perm.max, NA)
        n.otu.perm.max = ifelse(test.otu, n.perm.max, NA)
    }
        
    if (n.perm.max > 0) {
        
        
        n.pvalue.cal.min = 1000
        n.pvalue.cal.step = 100
        n.perm.block = 1000
        
        n.stable.max=10 # n.pvalue.cal.step*n.stable.max=1000
        
        
        otu.smallp = 1:n.otu
        n.otu.smallp = n.otu
        
        if (test.global) 
        {
            global.tests.stopped = FALSE
            global.freq = ldm.obs.freq$ve.global
            global.freq.perm = array(NA, dim=c(n.var1, n.rarefy, n.global.perm.max))
            n.global.freq = 0
            n.global.tran = n.global.perm.max # to satisfy the "if" condition
            if (!freq.scale.only) {
                global.tran = ldm.obs.tran$ve.global
                global.tran.perm = array(NA, dim=c(n.var1, n.rarefy, n.global.perm.max))
                
                n.global.tran = 0
            }
        
        }    
        
      
        if (test.otu)
        {
            otu.tests.stopped  = FALSE
            otu.freq = ldm.obs.freq$ve.otu
            
            n.perm.tmp = ifelse(test.global, max(n.global.perm.max, n.pvalue.cal.min), n.pvalue.cal.min)
            
            otu.freq.perm = array(NA, c(n.var1, n.otu, n.perm.tmp))
            
            n.otu.freq = 0
            
            Aset.freq = matrix(TRUE, n.var1, n.otu)
            
            p.otu.freq = matrix(NA, n.var1, n.otu)
            p.otu.tran = NULL
            p.otu.omni = NULL
            
            if (!freq.scale.only) {
                otu.tran = ldm.obs.tran$ve.otu
                otu.tran.perm = array(NA, c(n.var1, n.otu, n.perm.tmp))
                n.otu.tran = 0
                
                Aset.tran = matrix(TRUE, n.var1, n.otu)
                Aset.omni = matrix(TRUE, n.var1, n.otu)
                
                p.otu.tran = matrix(NA, n.var1, n.otu)
                p.otu.omni = matrix(NA, n.var1, n.otu)
            }
            
        }
      
        tol.eq = 10^-8
        
        n.perm.completed = 0
        n.global.perm.completed = n.global.perm.max
        n.otu.perm.completed = n.otu.perm.max
        
        n.stable.freq = 0
        if (!freq.scale.only) {
            n.stable.tran = 0
            n.stable.omni = 0
        }
        
        set.seed(seed) # can be removed ???
        
        for (i.sim in 1:n.perm.max) {
            
            i.sim.r = i.sim%%n.perm.block
            if (i.sim.r==0) i.sim.r = n.perm.block
            
            if (i.sim.r==1) {
                cat("permutations:", i.sim, "\n")
                perm = shuffleSet(n.obs, n.perm.block, CTRL)
            }
            
            
            n.perm.completed = n.perm.completed + 1
            inv.n.perm.completed = 1/n.perm.completed
            inv.n.perm.completed.1 = 1/(n.perm.completed+1)
            
            #------------------------------------------------
            # reduce OTUs to speed-up computation
            #------------------------------------------------
            
            if (i.sim > 100000) {
                n.pvalue.cal.min = 10000
                n.pvalue.cal.step = 1000
            }
            
            if (test.otu & i.sim > n.pvalue.cal.min & i.sim %% n.pvalue.cal.min==1){ # 1001, 2001, 3001, ...
                
                global.done = TRUE
                if (test.global) if (!global.tests.stopped & i.sim <= n.global.perm.max) global.done = FALSE
                
                if (global.done) {
                
                    if (!freq.scale.only) {
                        w.otu.smallp = which(apply(rbind(Aset.freq, Aset.tran, Aset.omni), 2, any))
                    } else {
                        w.otu.smallp = which(apply(Aset.freq, 2, any))
                    }
                    
                    cat("number of OTUs do not meet early stopping criterion:", length(w.otu.smallp), "\n")
                    
                    if (length(w.otu.smallp) != n.otu.smallp) {
                    
                        otu.smallp = otu.smallp[w.otu.smallp]
                        n.otu.smallp = length(otu.smallp)
                        
                        n.otu.freq = n.otu.freq[,w.otu.smallp,drop=FALSE]
                        Aset.freq = Aset.freq[,w.otu.smallp,drop=FALSE]
                        if (!freq.scale.only) {
                            n.otu.tran = n.otu.tran[,w.otu.smallp,drop=FALSE]
                            Aset.tran = Aset.tran[,w.otu.smallp,drop=FALSE]
                            Aset.omni = Aset.omni[,w.otu.smallp,drop=FALSE]
                        }
                    }
                    
                    otu.freq.perm.smallp = otu.freq.perm[,w.otu.smallp,1:(i.sim-1),drop=FALSE]
                    otu.freq.perm = array(NA, c(n.var1, n.otu.smallp, i.sim-1+n.pvalue.cal.min))
                    otu.freq.perm[,,1:(i.sim-1)] = otu.freq.perm.smallp
                    rm(otu.freq.perm.smallp)
                    
                    if (!freq.scale.only) {
                        otu.tran.perm.smallp = otu.tran.perm[,w.otu.smallp,1:(i.sim-1),drop=FALSE]
                        otu.tran.perm = array(NA, c(n.var1, n.otu.smallp, i.sim-1+n.pvalue.cal.min))
                        otu.tran.perm[,,1:(i.sim-1)] = otu.tran.perm.smallp
                        rm(otu.tran.perm.smallp)
                    }
                    
                }
            }


            # perform permutations                   
        
            x.perm = fit.ldm$x[perm[i.sim.r,], ]
                
            if (!all_rarefy) {
                ldm.perm.freq = ldm.stat(x=x.perm, low=low, up=up, 
                                       resid=resid.freq[,otu.smallp,,,drop=FALSE], ss.tot=ss.tot.freq[,otu.smallp,,drop=FALSE], adjust.for.confounders=adjust.for.confounders)
                if (!freq.scale.only) ldm.perm.tran = ldm.stat(x=x.perm, low=low, up=up, 
                                                              resid=resid.tran[,otu.smallp,,,drop=FALSE], ss.tot=ss.tot.tran[,otu.smallp,,drop=FALSE], adjust.for.confounders=adjust.for.confounders)
            } else {
                ldm.perm.freq = ldm.stat.allrarefy(x=x.perm, low=fit.ldm$low, up=fit.ldm$up, # n.otu.small???
                                                resid=fit.ldm$resid[,otu.smallp,,drop=FALSE], ss.tot=fit.ldm$ss.tot[,otu.smallp,drop=FALSE], 
                                                P.resid=fit.ldm$P.resid, ss.tot.1=fit.ldm$ss.tot.1[,otu.smallp,drop=FALSE], 
                                                phi_1phi=fit.ldm$phi_1phi[,otu.smallp,drop=FALSE],
                                                adjust.for.confounders=adjust.for.confounders)
            }

            if (test.global & i.sim <= n.global.perm.max) {
                if (!global.tests.stopped) {
                    global.freq.perm[,,i.sim] = ldm.perm.freq$ve.global
                    n.global.freq = n.global.freq + (ldm.perm.freq$ve.global > global.freq + tol.eq) + (ldm.perm.freq$ve.global > global.freq - tol.eq)
                    if (!freq.scale.only) {
                        global.tran.perm[,,i.sim] = ldm.perm.tran$ve.global
                        n.global.tran = n.global.tran + (ldm.perm.tran$ve.global > global.tran + tol.eq) + (ldm.perm.tran$ve.global > global.tran - tol.eq)
                    }
               }
            }
        
            if (test.otu) {
                if (!otu.tests.stopped) {
                    otu.freq.perm[,,i.sim] = ldm.perm.freq$ve.otu
                    n.otu.freq = n.otu.freq + (ldm.perm.freq$ve.otu>otu.freq[,otu.smallp,drop=FALSE]+tol.eq) + (ldm.perm.freq$ve.otu>otu.freq[,otu.smallp,drop=FALSE]-tol.eq)
                    if (!freq.scale.only) {
                        otu.tran.perm[,,i.sim] = ldm.perm.tran$ve.otu
                        n.otu.tran = n.otu.tran + (ldm.perm.tran$ve.otu>otu.tran[,otu.smallp,drop=FALSE]+tol.eq) + (ldm.perm.tran$ve.otu>otu.tran[,otu.smallp,drop=FALSE]-tol.eq)
                    }
                    
                }
            }
        
        
            if ((i.sim %% n.pvalue.cal.min == 0) 
                | (i.sim > n.pvalue.cal.min & i.sim %% n.pvalue.cal.step == 0) 
                | ifelse(is.na(n.global.perm.max), TRUE, (i.sim==n.global.perm.max)) 
                | (i.sim==n.perm.max)) {
          
                if (test.global & i.sim <= n.global.perm.max) {
                    if (!global.tests.stopped) {
                        
                        ################
                        # test global
                        ################
    
                        if ((all(n.global.freq >= n.rej.stop*2) & all(n.global.tran >= n.rej.stop*2)) 
                            | (i.sim==n.global.perm.max) 
                            | (i.sim==n.perm.max)) {
                            
                            p.global.freq = ifelse((n.global.freq >= n.rej.stop*2), 0.5*n.global.freq*inv.n.perm.completed, (0.5*n.global.freq+1)*inv.n.perm.completed.1)

                            if (!freq.scale.only) {
                                p.global.tran = ifelse((n.global.tran >= n.rej.stop*2), 0.5*n.global.tran*inv.n.perm.completed, (0.5*n.global.tran+1)*inv.n.perm.completed.1)
                                
                                p.global.freq.tmp <- 0.5*n.global.freq # omit (1/n.perm.completed) for computation efficiency
                                p.global.tran.tmp <- 0.5*n.global.tran 
                                
                                pmin.global.omni <- pmin(p.global.freq.tmp, p.global.tran.tmp)
                                pnull.global.freq <- (n.perm.completed + 0.5 - apply(global.freq.perm[,,1:n.perm.completed,drop=FALSE], c(1,2), rank))
                                pnull.global.tran <- (n.perm.completed + 0.5 - apply(global.tran.perm[,,1:n.perm.completed,drop=FALSE], c(1,2), rank))
                                pnullmin.global.omni <- pmin(pnull.global.freq, pnull.global.tran)
                                
                                if (length(dim(pnullmin.global.omni))==3) {
                                    pnullmin.global.omni <- aperm(pnullmin.global.omni, c(2,3,1))
                                } else {
                                    pnullmin.global.omni <- array(pnullmin.global.omni, c(dim(pnullmin.global.omni), 1))
                                }
                                
                                n.global.omni <- apply( (pnullmin.global.omni < c(pmin.global.omni) - tol.eq), c(1,2), sum) + 0.5 * apply( (abs(pnullmin.global.omni - c(pmin.global.omni)) < tol.eq), c(1,2), sum)
                                p.global.omni = ifelse((n.global.omni >= n.rej.stop), n.global.omni*inv.n.perm.completed, (n.global.omni+1)*inv.n.perm.completed.1)
                                
                                if (all(n.global.freq >= n.rej.stop*2) 
                                    & all(n.global.tran >= n.rej.stop*2)
                                    & all(n.global.omni >= n.rej.stop)) {
                                    global.tests.stopped = TRUE
                                    cat("global test stopped at permutation", i.sim, "\n")
                                    n.global.perm.completed = i.sim
                                }
                            } else {
                                if (all(n.global.freq >= n.rej.stop*2)) {
                                    global.tests.stopped = TRUE
                                    cat("global test stopped at permutation", i.sim, "\n")
                                    n.global.perm.completed = i.sim
                                }
                            }                            

                        } 
                    }
                } 
          
                if (test.otu) {
                    if (!otu.tests.stopped) {
                        
                        ################
                        # test otu
                        ################
                
                        if (any(Aset.freq)) {
                            AtoB.freq <- Aset.freq & (n.otu.freq >= n.rej.stop*2)
                            Aset.freq <- Aset.freq & !AtoB.freq
                            p.otu.freq[,otu.smallp][AtoB.freq] <- 0.5*n.otu.freq[AtoB.freq]*inv.n.perm.completed
                            p.otu.freq[,otu.smallp][Aset.freq] <- (0.5*n.otu.freq[Aset.freq]+1)*inv.n.perm.completed.1
                        
                            q.otu.freq <- t(apply(p.otu.freq, 1, fdr.Sandev))
                        
                            Aset.freq.meet.criteria <- apply(((q.otu.freq[,otu.smallp,drop=FALSE] < fdr.nominal) & Aset.freq) | (!Aset.freq), 1, all)
                            n.stable.freq <- ifelse(Aset.freq.meet.criteria, n.stable.freq + Aset.freq.meet.criteria, 0)
                            Aset.freq.rm.row <- (n.stable.freq >= n.stable.max)
                            Aset.freq[Aset.freq.rm.row,] = FALSE
                        }
                
                        if (!freq.scale.only) {
                            if (any(Aset.tran)) {
                                AtoB.tran <- Aset.tran & (n.otu.tran >= n.rej.stop*2)
                                Aset.tran <- Aset.tran & !AtoB.tran
                                p.otu.tran[,otu.smallp][AtoB.tran] <- 0.5*n.otu.tran[AtoB.tran]*inv.n.perm.completed
                                p.otu.tran[,otu.smallp][Aset.tran] <- (0.5*n.otu.tran[Aset.tran]+1)*inv.n.perm.completed.1
                                
                                q.otu.tran <- t(apply(p.otu.tran, 1, fdr.Sandev))
                                
                                Aset.tran.meet.criteria <- apply(((q.otu.tran[,otu.smallp,drop=FALSE] < fdr.nominal) & Aset.tran) | (!Aset.tran), 1, all)
                                n.stable.tran <- ifelse(Aset.tran.meet.criteria, n.stable.tran + Aset.tran.meet.criteria, 0)
                                Aset.tran.rm.row <- (n.stable.tran >= n.stable.max)
                                Aset.tran[Aset.tran.rm.row,] = FALSE
                            }
                            
                            if ((!any(Aset.freq) & !any(Aset.tran)) 
                                | (i.sim %% n.pvalue.cal.min==0)
                                | (i.sim==n.perm.max)) {
                                
                                p.otu.freq.tmp <- 0.5*n.otu.freq # *edited*: omit (1/n.perm.completed) to save time
                                p.otu.tran.tmp <- 0.5*n.otu.tran
                                pmin.otu.omni <- pmin(p.otu.freq.tmp, p.otu.tran.tmp)
                                
                                pnull.otu.freq <- n.perm.completed + 0.5 - apply(otu.freq.perm[,,1:n.perm.completed,drop=FALSE], c(1,2), rank)
                                pnull.otu.tran <- n.perm.completed + 0.5 - apply(otu.tran.perm[,,1:n.perm.completed,drop=FALSE], c(1,2), rank)
                                pnullmin.otu.omni <- pmin(pnull.otu.freq, pnull.otu.tran)
                                
                                if (length(dim(pnullmin.otu.omni))==3) {
                                    pnullmin.otu.omni <- aperm(pnullmin.otu.omni, c(2,3,1))
                                } else {
                                    pnullmin.otu.omni <- array(pnullmin.otu.omni, c(dim(pnullmin.otu.omni), 1))
                                }
                                
                                n.otu.omni <- apply( (pnullmin.otu.omni < c(pmin.otu.omni) - tol.eq), c(1,2), sum) + 0.5 * apply( (abs(pnullmin.otu.omni - c(pmin.otu.omni)) < tol.eq), c(1,2), sum)
                                
                                if (any(Aset.omni)) {
                                    
                                    AtoB.omni <- Aset.omni & (n.otu.omni >= n.rej.stop)
                                    Aset.omni <- Aset.omni & !AtoB.omni
                                    
                                    p.otu.omni[,otu.smallp][AtoB.omni] <- n.otu.omni[AtoB.omni]*inv.n.perm.completed
                                    p.otu.omni[,otu.smallp][Aset.omni] <- (n.otu.omni[Aset.omni]+1)*inv.n.perm.completed.1
                                    
                                    q.otu.omni <- t(apply(p.otu.omni, 1, fdr.Sandev))
                                    
                                    Aset.omni.meet.criteria <- apply(((q.otu.omni[,otu.smallp,drop=FALSE] < fdr.nominal) & Aset.omni) | (!Aset.omni), 1, all)
                                    n.stable.omni <- ifelse(Aset.omni.meet.criteria, n.stable.omni + Aset.omni.meet.criteria, 0)
                                    Aset.omni.rm.row <- (n.stable.omni >= n.stable.max)
                                    Aset.omni[Aset.omni.rm.row,] = FALSE
                                }
                                
                                if (!any(Aset.freq) 
                                    & !any(Aset.tran) 
                                    & !any(Aset.omni)) {
                                    otu.tests.stopped = TRUE 
                                    cat("otu test stopped at permutation", i.sim, "\n")
                                    n.otu.perm.completed = i.sim
                                }
                            }
                        } else {
                            if (!any(Aset.freq)) {
                                otu.tests.stopped = TRUE 
                                cat("otu test stopped at permutation", i.sim, "\n")
                                n.otu.perm.completed = i.sim
                            }
                            q.otu.tran <- NULL
                            q.otu.omni <- NULL
                        }
                        
                    }
                }# if test.otu
          
                if (test.global + test.otu == 2) {
                    if (global.tests.stopped + otu.tests.stopped == 2) break
                    if (otu.tests.stopped == TRUE & i.sim >= n.global.perm.max) break
                } 
          
                if ( test.global + test.otu == 1) {
                    if (!is.null(global.tests.stopped)) {if (global.tests.stopped | i.sim >= n.global.perm.max) break}
                    if (!is.null(otu.tests.stopped)) {if (otu.tests.stopped) break}
                }
          
            }# check if stop early 
        
        }# permutation
        
        n.perm.completed = max(n.global.perm.completed, n.otu.perm.completed, na.rm=TRUE)
        
    }# if (n.perm.max > 0)

    
    otu.names <- colnames(otu.table)
    colnames(ldm.obs.freq$ve.otu) <- otu.names
    if (!freq.scale.only) colnames(ldm.obs.tran$ve.otu) <- otu.names
    if (!is.null(p.otu.freq)) colnames(p.otu.freq) <- otu.names
    if (!is.null(p.otu.tran)) colnames(p.otu.tran) <- otu.names
    if (!is.null(p.otu.omni)) colnames(p.otu.omni) <- otu.names
    if (!is.null(q.otu.freq)) colnames(q.otu.freq) <- otu.names
    if (!is.null(q.otu.tran)) colnames(q.otu.tran) <- otu.names
    if (!is.null(q.otu.omni)) colnames(q.otu.omni) <- otu.names
    
    # confounder
    
    VE.df.confounders = NULL
    VE.global.freq.confounders = NULL
    VE.otu.freq.confounders = NULL
    VE.global.tran.confounders = NULL
    VE.otu.tran.confounders = NULL
    
    if (!all_rarefy) {
        if (adjust.for.confounders) {
            i.conf <- fit.ldm$low[1]:fit.ldm$up[1]
            VE.df.confounders <- length(i.conf)
            
            VE.global.freq.confounders <- sum((fit.ldm$d.freq[i.conf])^2)
            wt <- fit.ldm$d.freq[i.conf] * t(fit.ldm$v.freq[, i.conf]) 
            if (is.vector(wt)) VE.otu.freq.confounders = wt^2
            else               VE.otu.freq.confounders = colSums(wt^2)
            
            if (!freq.scale.only) {
                VE.global.tran.confounders <- sum((fit.ldm$d.tran[i.conf])^2)
                wt <- fit.ldm$d.tran[i.conf] * t(fit.ldm$v.tran[, i.conf]) 
                if (is.vector(wt)) VE.otu.tran.confounders = wt^2
                else               VE.otu.tran.confounders = colSums(wt^2)
            }
        }
    }
    
    # submodels
    
    VE.df.submodels = NULL
    VE.global.freq.submodels = NULL
    VE.otu.freq.submodels = NULL
    VE.global.tran.submodels = NULL
    VE.otu.tran.submodels = NULL
    VE.global.freq.residuals <- NULL
    VE.global.tran.residuals <- NULL
    i.col = NULL
    beta = NULL
    beta.name = NULL
    
    
    for (k in 1:n.var1) {
        k1 = k + as.numeric(adjust.for.confounders)
        i.m <- fit.ldm$low[k1]:fit.ldm$up[k1]
        i.col = c(i.col, i.m)
        
        for (im in i.m) {
            corr = t(cor(model[[k1]], fit.ldm$x[,im]))
            
            w = which(corr[1,]>0.9999)
            if (length(w)==0) {
                w = which.max(abs(corr[1,]))
            }
            if (corr[1,w] < 0) {
                fit.ldm$x[,im] = -fit.ldm$x[,im]
                if (!all_rarefy) {
                    fit.ldm$v.freq[,im] = -fit.ldm$v.freq[,im]
                }
            }
            beta.name = c(beta.name, colnames(model[[k1]])[w])
            if (!all_rarefy) {
                beta = rbind(beta, t(fit.ldm$v.freq[,im])*fit.ldm$d.freq[im])
            } else {
                beta = rbind(beta, -t(fit.ldm$x[,im]) %*% fit.ldm$phi)
            }
        }
        
        if (!all_rarefy) {
            VE.df.submodels <- c(VE.df.submodels, length(i.m))
            
            VE.global.freq.submodels <- c(VE.global.freq.submodels, sum((fit.ldm$d.freq[i.m])^2))
            wt <- fit.ldm$d.freq[i.m] * t(fit.ldm$v.freq[, i.m])
            if (is.vector(wt)) VE.otu.freq.submodels = rbind(VE.otu.freq.submodels, wt^2)
            else               VE.otu.freq.submodels = rbind(VE.otu.freq.submodels, colSums(wt^2))
            
            if (!freq.scale.only) {
                VE.global.tran.submodels <- c(VE.global.tran.submodels, sum((fit.ldm$d.tran[i.m])^2))
                wt <- fit.ldm$d.tran[i.m] * t(fit.ldm$v.tran[, i.m])
                if (is.vector(wt)) VE.otu.tran.submodels = rbind(VE.otu.tran.submodels, wt^2)
                else               VE.otu.tran.submodels = rbind(VE.otu.tran.submodels, colSums(wt^2))
            }
        }
    }
    
    beta = data.frame(beta)
    rownames(beta) = beta.name
    colnames(beta) = colnames(otu.table)
    
    phi = NULL
    if (all_rarefy) phi = fit.ldm$phi
    
    # residuals
    
    if (!all_rarefy) {
        i.all <- fit.ldm$low[1]:fit.ldm$up[n.var]
        
        VE.global.freq.residuals <- fit.ldm$d.freq[-i.all]^2
        VE.global.tran.residuals <- NULL
        if (!freq.scale.only) VE.global.tran.residuals <- fit.ldm$d.tran[-i.all]^2
    }
    
    detected.otu.freq = NULL
    n.detected.otu.freq = NULL
    detected.otu.tran = NULL
    n.detected.otu.tran = NULL
    detected.otu.omni = NULL
    n.detected.otu.omni = NULL
    if (!is.null(q.otu.freq)) {
        if (nrow(q.otu.freq)>1) {
            detected.otu.freq = apply(q.otu.freq, 1, function(x) colnames(q.otu.freq)[which(x<fdr.nominal)])
            n.detected.otu.freq = lapply(detected.otu.freq, length)
        } else {
            detected.otu.freq = colnames(q.otu.freq)[which(q.otu.freq[1,]<fdr.nominal)]
            n.detected.otu.freq = length(detected.otu.freq)
        }
    }
    if (!is.null(q.otu.tran)) {
        if (nrow(q.otu.tran)>1) {
            detected.otu.tran = apply(q.otu.tran, 1, function(x) colnames(q.otu.tran)[which(x<fdr.nominal)])
            n.detected.otu.tran = lapply(detected.otu.tran, length)
        } else {
            detected.otu.tran = colnames(q.otu.tran)[which(q.otu.tran[1,]<fdr.nominal)]
            n.detected.otu.tran = length(detected.otu.tran)
        }
    }
    if (!is.null(q.otu.omni)) {
        if (nrow(q.otu.omni)>1) {
            detected.otu.omni = apply(q.otu.omni, 1, function(x) colnames(q.otu.omni)[which(x<fdr.nominal)])
            n.detected.otu.omni = lapply(detected.otu.omni, length)
        } else {
            detected.otu.omni = colnames(q.otu.omni)[which(q.otu.omni[1,]<fdr.nominal)]
            n.detected.otu.omni = length(detected.otu.omni)
        }
    }
    
    res = list( x=fit.ldm$x,
                dist=d.gower,
                mean.freq=mean.freq,
                y.freq=y.freq,
                v.freq=fit.ldm$v.freq,
                d.freq=fit.ldm$d.freq,
                y.tran=y.tran,
                v.tran=fit.ldm$v.tran,
                d.tran=fit.ldm$d.tran,
                low=fit.ldm$low,
                up=fit.ldm$up,
                beta=beta,
                phi=1-phi,
                VE.global.freq.confounders=VE.global.freq.confounders,
                VE.global.freq.submodels=VE.global.freq.submodels,
                VE.global.freq.residuals=VE.global.freq.residuals,
                VE.otu.freq.confounders=VE.otu.freq.confounders,
                VE.otu.freq.submodels=VE.otu.freq.submodels,
                VE.global.tran.confounders=VE.global.tran.confounders,
                VE.global.tran.submodels=VE.global.tran.submodels,
                VE.global.tran.residuals=VE.global.tran.residuals,
                VE.otu.tran.confounders=VE.otu.tran.confounders,
                VE.otu.tran.submodels=VE.otu.tran.submodels,
                VE.df.confounders=VE.df.confounders,
                VE.df.submodels=VE.df.submodels,
                
                F.global.freq=ldm.obs.freq$ve.global, 
                F.global.tran=ldm.obs.tran$ve.global, 
                F.otu.freq=ldm.obs.freq$ve.otu, 
                F.otu.tran=ldm.obs.tran$ve.otu,
                p.global.freq=p.global.freq, 
                p.global.tran=p.global.tran, 
                p.global.omni=p.global.omni,
                p.otu.freq=p.otu.freq,
                p.otu.tran=p.otu.tran,
                p.otu.omni=p.otu.omni,
                q.otu.freq=q.otu.freq,
                q.otu.tran=q.otu.tran,
                q.otu.omni=q.otu.omni,
                
                detected.otu.freq = detected.otu.freq,
                n.detected.otu.freq = n.detected.otu.freq,
                detected.otu.tran = detected.otu.tran,
                n.detected.otu.tran = n.detected.otu.tran,
                detected.otu.omni = detected.otu.omni,
                n.detected.otu.omni = n.detected.otu.omni,
                
                p.global.pa=p.global.freq,
                p.otu.pa=p.otu.freq,
                q.otu.pa=q.otu.freq,
                
                detected.otu.pa = detected.otu.freq,
                n.detected.otu.pa = n.detected.otu.freq,
                
                n.perm.completed=n.perm.completed,
                global.tests.stopped=global.tests.stopped,
                otu.tests.stopped=otu.tests.stopped,
                seed=seed)
      
    return(res)
    
} # ldm



calculate.x.and.resid = function( d.gower, y.freq, y.tran, index, m, adjust.for.confounders) {
    
    n.var = length(index)
    n.otu = ncol(y.freq)
    n.sam = nrow(d.gower)
    ndf.nominal = rep(0, n.var+1)
    
    tol.d = 10^-8
    
    #--------------------------------------------------------------------------
    # construct directions matrix x 
    # from each set of covariates in the list vars
    #--------------------------------------------------------------------------
    
    d.resid = d.gower
    
    for (i in 1:n.var) 
    {
        var = m[,1:index[i]]
        
        svd.var = svd(var)   
        use = (svd.var$d>tol.d)    
        
        hat.matrix = svd.var$u[, use] %*% t( svd.var$u[, use] )
        
        #---------------------
        # calculate direction
        #---------------------
        
        n.dim = dim( hat.matrix)[1]
        
        d.model = hat.matrix %*% d.resid
        d.model = d.model %*% hat.matrix
        
        es.model = eigen(d.model, symmetric=TRUE) # es: eigen system in Mathematica
        
        use = ( abs(es.model$values)>tol.d )
        
        ndf.model = sum( use )
        
        x.model = es.model$vectors[, use]
        e.model = es.model$values[use]
        
        hat.matrix.bar = diag(n.dim)  - hat.matrix
        d.resid = hat.matrix.bar %*% d.resid
        d.resid = d.resid %*% hat.matrix.bar
        
        #-----------------------------
        # end of calculating direction
        #-----------------------------    
        
        if (i==1) {
            x = x.model
            e = e.model
        } else {   
            x = cbind(x, x.model)
            e = c(e, e.model )
        }
        
        ndf.nominal[i] = ndf.model
    }
    
    es.resid = eigen(d.resid, symmetric=TRUE)
    use = which( abs(es.resid$values)>tol.d )
    
    ndf.nominal[n.var+1] = length(use)
    x = cbind(x, es.resid$vectors[, use])
    e = c(e, es.resid$values[use])
    
    
    #---------------------------------------------------------
    # fit LDM to x
    #---------------------------------------------------------
    
    x = matrix(x, nrow=nrow(d.gower)) 
    
    wt.freq = t(x) %*% y.freq    
    d.freq = sqrt(apply(wt.freq^2, 1, sum))
    v.freq = t((1/d.freq)*wt.freq)
    d.tran = NULL
    v.tran = NULL
    if (!is.null(y.tran)) {
        wt.tran = t(x) %*% y.tran    
        d.tran = sqrt(apply(wt.tran^2, 1, sum))
        v.tran = t((1/d.tran)*wt.tran)
    }
    
    #-------------------------------------------------
    # low, up
    #-------------------------------------------------
    
    low = rep(NA, n.var)
    up = rep(NA, n.var)
    
    up.prev = 0
    
    for (k in 1:n.var)
    {
        low[k] = up.prev + 1
        up[k] = up.prev + ndf.nominal[k]
        up.prev = up[k]
    }
    
    #-------------------------------------------------
    # calculate resid, ss.tot
    #-------------------------------------------------
    
    n.var1 = ifelse(adjust.for.confounders, n.var-1, n.var)
    
    ss.tot.freq = matrix( rep(NA, n.otu*n.var1), nrow=n.var1)
    resid.freq = array( NA, dim=c( dim(y.freq), n.var1 ) ) 
    ss.tot.tran = NULL
    resid.tran = NULL
    if (!is.null(y.tran)) {
        ss.tot.tran = matrix( rep(NA, n.otu*n.var1), nrow=n.var1)
        resid.tran = array( NA, dim=c( dim(y.tran), n.var1 ) ) 
    }
    
    for (k in 1:n.var1) {
        
        k1 = ifelse(adjust.for.confounders, k+1, k)
        use = setdiff( 1:up[n.var], low[k1]:up[k1] )
        
        resid.freq[,,k] = y.freq - x[,use,drop=FALSE] %*% wt.freq[use,,drop=FALSE]
        ss.tot.freq[k,] = colSums( resid.freq[,,k,drop=FALSE]^2 )
        if (!is.null(y.tran)) {
            resid.tran[,,k] = y.tran - x[,use,drop=FALSE] %*% wt.tran[use,,drop=FALSE]
            ss.tot.tran[k,] = colSums( resid.tran[,,k,drop=FALSE]^2 )
        } 
    }
    
    res = list( x=x,
                d.freq=d.freq,
                v.freq=v.freq,
                d.tran=d.tran,
                v.tran=v.tran,
                low=low,
                up=up,
                resid.freq=resid.freq,
                resid.tran=resid.tran,
                ss.tot.freq=ss.tot.freq,
                ss.tot.tran=ss.tot.tran,
                ndf=ndf.nominal)
    
    return(res)
    
} # calculate.x.and.resid


ldm.stat = function(x, low, up, resid, ss.tot, adjust.for.confounders) {
    
    #---------------------------------------------
    #  calculate FL statistics for each model
    #---------------------------------------------
    
    n.var = length(low)
    n.otu = length(resid[1,,1,1])
    n.rarefy = length(resid[1,1,1,])
    
    n.var1 = ifelse(adjust.for.confounders, n.var-1, n.var)
    
    ve.global = matrix(0, n.var1, n.rarefy)
    ve.otu = matrix(0, n.var1, n.otu)

    for (r in 1:n.rarefy) {
        for (k in 1:n.var1) {
            
            k1 = k + as.numeric(adjust.for.confounders)
            use = low[k1]:up[k1]
            
            wt = t( x[, use] ) %*% resid[,,k,r]
            ve.otu.k = colSums( wt^2 )
            
            if (n.var==1) {
                sigma.k = ss.tot[k,,r] - ve.otu.k
            } else {
                use = 1:up[n.var]
                wt.cum = t( x[, use] ) %*% resid[,,k,r]
                sigma.k = ss.tot[k,,r] - colSums( wt.cum^2 )
            }
            
            sigma.tmp = ifelse(sigma.k>1e-16, sigma.k, 1)
            ve.otu[k,] = ve.otu[k,] + ve.otu.k/sigma.tmp
            ve.global[k, r:n.rarefy] = ve.global[k, r:n.rarefy] + sum( ve.otu.k )/sum( sigma.k )
            
        }
    }
    
    out = list( ve.otu=ve.otu, 
                ve.global=ve.global)   
    
    return(out)
    
} # ldm.stat




log.int.seq = function(low, up, log.int) {
    return(ifelse(low==up, 0, sum(log.int[(low+1):up])))
}

calculate.x.and.resid.allrarefy = function( y, index, m, adjust.for.confounders) {
    
    n.var = length(index)
    n.otu = ncol(y)
    n.sam = nrow(y)
    ndf.nominal = rep(0, n.var+1)
    
    tol.d = 10^-8
    
    #--------------------------------------------------------------------------
    # construct directions matrix x 
    # from each set of covariates in the list vars
    #--------------------------------------------------------------------------
    
    # x = gramSchmidt(m)$Q
    
    d.resid = diag(n.sam)
    
    for (i in 1:n.var) 
    {
        var = m[,1:index[i]]
        
        svd.var = svd(var)   
        use = (svd.var$d>tol.d)    
        
        hat.matrix = svd.var$u[, use] %*% t( svd.var$u[, use] )
        
        #---------------------
        # calculate direction
        #---------------------
        
        n.dim = dim( hat.matrix)[1]
        
        d.model = hat.matrix %*% d.resid
        d.model = d.model %*% hat.matrix
        
        es.model = eigen(d.model, symmetric=TRUE) # es: eigen system in Mathematica
        
        use = ( abs(es.model$values)>tol.d )
        
        ndf.model = sum( use )
        
        x.model = es.model$vectors[, use]
        e.model = es.model$values[use]
        
        hat.matrix.bar = diag(n.dim)  - hat.matrix
        d.resid = hat.matrix.bar %*% d.resid
        d.resid = d.resid %*% hat.matrix.bar
        
        #-----------------------------
        # end of calculating direction
        #-----------------------------    
        
        if (i==1) {
            x = x.model
            e = e.model
        } else {   
            x = cbind(x, x.model)
            e = c(e, e.model )
        }
        
        ndf.nominal[i] = ndf.model
    }
    
    es.resid = eigen(d.resid, symmetric=TRUE)
    use = which( abs(es.resid$values)>tol.d )
    
    ndf.nominal[n.var+1] = length(use)
    x = cbind(x, es.resid$vectors[, use])
    e = c(e, es.resid$values[use])
    
    #-------------------------------------------------
    # low, up
    #-------------------------------------------------
    
    low = rep(NA, n.var)
    up = rep(NA, n.var)
    
    up.prev = 0
    
    for (k in 1:n.var)
    {
        low[k] = up.prev + 1
        up[k] = up.prev + ndf.nominal[k]
        up.prev = up[k]
    }
    
    #-------------------------------------------------
    # calculate phi
    #-------------------------------------------------
    
    lib.size = rowSums(y)
    rarefy.depth = min(rowSums(y))
    log.int = log(1:max(lib.size)) 
    vec.y = as.vector(y)
    vec.tmp = rep(0, length(vec.y))
    phi = rep(NA, length(vec.y))
    
    w = which(lib.size-rarefy.depth-vec.y >= 0)
    phi[-w] = 0
    
    a = mapply(log.int.seq, (lib.size-rarefy.depth-vec.y)[w], (lib.size-rarefy.depth-vec.tmp)[w], MoreArgs=list(log.int=log.int))
    b = mapply(log.int.seq, (lib.size-vec.y)[w], (lib.size-vec.tmp)[w], MoreArgs=list(log.int=log.int))
    phi[w] = exp(a - b)
    phi = matrix(phi, nrow=n.sam)
    phi_1phi = phi*(1-phi)
    
    #-------------------------------------------------
    # calculate resid, ss.tot
    #-------------------------------------------------
    
    n.var1 = ifelse(adjust.for.confounders, n.var-1, n.var)
    
    wt = t(x) %*% phi  
    
    resid = array( NA, dim=c( n.sam, n.otu, n.var1 ) ) 
    ss.tot = matrix( NA, nrow=n.var1, ncol=n.otu)
    
    P.resid = array( NA, dim=c(n.sam, n.sam, n.var1) ) 
    ss.tot.1 = matrix(NA, nrow=n.var1, ncol=n.otu)
    
    for (k in 1:n.var1) {
        
        k1 = ifelse(adjust.for.confounders, k+1, k)
        
        use = setdiff( 1:up[n.var], low[k1]:up[k1] )
        
        resid[,,k] = phi - x[,use,drop=FALSE] %*% wt[use,,drop=FALSE]
        ss.tot[k,] = colSums( resid[,,k]^2 )
        
        P.resid[,,k] = diag(n.sam) - x[,use,drop=FALSE] %*% t(x[,use,drop=FALSE])
        D_k = rowSums(P.resid[,,k]^2)
        ss.tot.1[k,] = colSums(D_k*phi_1phi)
    }
    
    res = list( x=x,
                low=low,
                up=up,
                resid=resid,
                ss.tot=ss.tot,
                P.resid=P.resid,
                ss.tot.1=ss.tot.1,
                phi = phi,
                phi_1phi=phi_1phi)
    
    return(res)
    
} # calculate.x.and.resid.allrarefy


ldm.stat.allrarefy = function(x, low, up, resid, ss.tot, P.resid, ss.tot.1, phi_1phi, adjust.for.confounders) {
    
    #---------------------------------------------
    #  calculate FL statistics for each model
    #---------------------------------------------
    
    n.var = length(low)
    n.sam = dim(resid)[1]
    n.otu = dim(resid)[2]
    
    n.var1 = ifelse(adjust.for.confounders, n.var-1, n.var)
    
    ve.otu = matrix(rep(NA, n.otu*n.var1), nrow=n.var1 )
    ve.global = rep(NA, n.var1)
    
    for (k in 1:n.var1) {
        
        k1 = k + as.numeric(adjust.for.confounders)
        
        use = low[k1]:up[k1]
        
        wt = t( x[, use,drop=FALSE] ) %*% resid[,,k]
        ve.otu.k = colSums( wt^2 )
        
        P.nume = P.resid[,,k] %*% x[, use,drop=FALSE]
        D_k = rowSums(P.nume^2)
        ve.otu.k.1 = colSums(D_k*phi_1phi)
        
        
        use = 1:up[n.var]
        
        wt.cum = t( x[, use,drop=FALSE] ) %*% resid[,,k]
        sigma.k = ss.tot[k,] - colSums( wt.cum^2 )
        
        P.denom = P.resid[,,k] %*% x[, use,drop=FALSE]
        D_k = rowSums(P.denom^2)
        sigma.k.1 = ss.tot.1[k,] - colSums(D_k*phi_1phi)
        
        ve.otu[k,] = ( ve.otu.k + ve.otu.k.1)/( sigma.k + sigma.k.1 )
        ve.global[k] = sum( ve.otu.k + ve.otu.k.1 )/sum( sigma.k + sigma.k.1 )
        
        ve.otu[k, which(is.na(ve.otu[k,]))] = 0  #Debugged: in case the denominator (sigma.k + sigma.k.1) is 0
    }
 
    out = list( ve.otu=ve.otu, 
                ve.global=ve.global)   
    
    return(out)
    
} # ldm.stat.allrarefy



#' PERMANOVA test of association based on the Freedman-Lane permutation scheme
#' 
#' This function performs the PERMANOVA test that can allow adjustment of
#' confounders and control of clustered data. It can also be used for testing 
#' presence-absence associations based on infinite number of rarefaction replicates. 
#' As in \code{ldm}, 
#' \code{permanovaFL} allows multiple sets of covariates to be tested, 
#' in the way that the sets are entered sequentially and the variance 
#' explained by each set is that part that remains after the previous 
#' sets have been fit. 
#' 
#' @param formula a symbolic description of the model to be fitted in the form
#'   of \code{data.matrix ~ sets of covariates} or \code{data.matrix |
#'   confounders ~ sets of covariates}. The details of model specification are
#'   given in "Details" of \code{ldm}. Additionally, in \code{permanovaFL}, the \code{data.matrix}
#'   can be either an OTU table or a distance matrix. If it is an OTU table,
#'   the distance matrix will be calculated internally using the OTU table, \code{tree} (if required), and 
#'   \code{dist.method}. If \code{data.matrix} is a distance
#'   matrix (having class \code{dist} or \code{matrix}), it can be squared and//or centered by
#'   specifying \code{square.dist} and \code{center.dist} (described below).  Distance matrices are distinguished
#'   from OTU tables by checking for symmetry of \code{as.matrix(data.matrix)}.
#' @param data an optional data frame, list or environment (or object coercible 
#' to a dataframe) containing the covariates of interest and confounding covariates. 
#' If not found in \code{data}, the covariates are taken from environment(formula), 
#' typically the environment from which \code{permanovaFL} is called. The default is .GlobalEnv.
#' @param tree a phylogenetic tree. Only used for calculating a 
#'   phylogenetic-tree-based distance matrix. Not needed if the calculation of 
#'   the requested distance does not involve a phylogenetic tree, or if a 
#'   distance matrix is directly imported through \code{formula}.
#' @param dist.method method for calculating the distance measure, partial
#' match to all methods supported by \code{vegdist} in the \code{vegan} package
#'  (i.e., "manhattan", "euclidean", "canberra", "bray", "kulczynski", "jaccard", "gower", 
#'  "altGower", "morisita", "horn", "mountford", "raup" , "binomial", "chao", "cao", "mahalanobis")
#'   as well as "hellinger" and "wt-unifrac". 
#'   Not used if a distance matrix is specified in \code{formula}.
#'   The default is "bray". 
#'   For more details, see the \code{dist.method} argument in the \code{ldm} function.
#' @param cluster.id cluster identifiers. The default is value of NULL should be used if the observations are 
#' not in clusters (i.e., independent).
#' @param strata a factor variable (or, character variable converted into a factor) to define strata (groups), within which to constrain permutations. 
#'   The default is NULL.
#' @param how a permutation control list, for users who want to specify their permutation control list using the \code{how} function 
#'   from the \code{permute} R package.  The default is NULL.
#' @param perm.within.type a character string that takes values "free", "none", "series", or "grid".  
#'   The default is "free" (for random permutations).
#' @param perm.between.type a character string that takes values "free", "none", or "series".  
#'   The default is "none".
#' @param perm.within.nrow a positive integer, only used if perm.within.type="grid". 
#'   The default is 0.  See the documentation for the R package \code{permute} for further details.
#' @param perm.within.ncol a positive integer, only used if perm.within.type="grid". 
#'   The default is 0.  See the documentation for the R package \code{permute} for further details.
#' @param n.perm.max the maximum number of permutations.
#'   The default is 5000.
#' @param n.rej.stop the minimum number of rejections (i.e., the permutation 
#'   statistic exceeds the observed statistic) to obtain before stopping. 
#'   The default is 100.
#' @param seed a user-supplied integer seed for the random number generator in the 
#'   permutation procedure. The default is NULL; with the default value, an integer seed will be 
#'   generated internally and randomly. In either case, the integer seed will be stored
#'   in the output object in case 
#'   the user wants to reproduce the permutation replicates.
#' @param square.dist a logical variable indicating whether to square the
#'   distance matrix. The default is TRUE.
#' @param center.dist a logical variable indicating whether to center the 
#'   distance matrix as described by Gower (1966). The default is TRUE.
#' @param scale.otu.table a logical variable indicating whether to scale the OTU table.
#'   For count data, this corresponds to dividing by the library size to give
#'   relative abundances. The default is TRUE.
#' @param binary a logical value indicating whether to perform presence-absence
#'   analysis. The default is FALSE (analyzing relative abundance data).
#' @param n.rarefy number of rarefactions. The default is 0 (no rarefaction).
#' @return  a list consisting of 
#' \item{F.statistics}{F statistics for the test of each set of covariates}
#' \item{p.permanova}{p-values for the test
#'   of each set of covariates} 
#' \item{n.perm.completed}{number of permutations completed}
#' \item{permanova.stopped}{a logical value indicating whether the 
#'   stopping criterion has been met by all tests of covariates}
#' \item{seed}{the seed that is user supplied or internally generated, stored in case 
#'   the user wants to reproduce the permutation replicates}
#' @keywords microbiome
#' @author Yi-Juan Hu <yijuan.hu@emory.edu>, Glen A. Satten <gsatten@emory.edu>
#' @export
#' @examples
#' 
#'#----------------------------------------------------------------
#'# Testing relative-abundance associations
#'#----------------------------------------------------------------
#'res.perm <- permanovaFL(throat.otu.tab5 | (Sex+AntibioticUse) ~ SmokingStatus+PackYears, 
#'                        data=throat.meta, dist.method="bray", seed=82955)
#'                        
#'#----------------------------------------------------------------
#'# Testing presence-absence associations: PERMANOVA-D2-A2 (recommended)
#'#----------------------------------------------------------------
#'res.perm.D2A2 <- permanovaFL(dist.mean.sq | (Sex+AntibioticUse) ~ SmokingStatus+PackYears, 
#'                             data=throat.meta, seed=82955, 
#'                             square.dist=FALSE)  # parameters for requesting PERMANOVA-D2-A2
#'                            
#'#----------------------------------------------------------------
#'# Testing presence-absence associations: PERMANOVA-F(5)
#'#----------------------------------------------------------------
#'res.perm.F <- permanovaFL(throat.otu.tab5 | (Sex+AntibioticUse) ~ SmokingStatus+PackYears, 
#'                          data=throat.meta, seed=82955, 
#'                          dist.method="jaccard", binary=TRUE,            # parameters 
#'                          n.rarefy=5)                  # for requesting PERMANOVA-F(5)
#'                          
#'#----------------------------------------------------------------
#'# Testing presence-absence associations: PERMANOVA-D2(100)
#'#----------------------------------------------------------------
#'dist.avg.D2 <- avgdist_squared(throat.otu.tab5, dist.method="jaccard", n.rarefy=100)
#'res.perm.D2 <- permanovaFL(dist.avg.D2 | (Sex+AntibioticUse) ~ SmokingStatus+PackYears, 
#'                           data=throat.meta, seed=82955,
#'                           square.dist=FALSE)  # parameter for requesting PERMANOVA-D2(100)
#'                           
#'#----------------------------------------------------------------
#'# Testing presence-absence associations: PERMANOVA-D(100)
#'#----------------------------------------------------------------
#'dist.avg.D <- as.matrix(avgdist(x=throat.otu.tab5, sample=min(rowSums(throat.otu.tab5)), 
#'                                dmethod="jaccard", tree=NULL, iterations=100, binary=TRUE))
#'res.perm.D <- permanovaFL(dist.avg.D | (Sex+AntibioticUse) ~ SmokingStatus+PackYears, 
#'                          data=throat.meta, seed=82955)  
#'                          
#'#-------------------------------------------------------------------------
#'# Testing associations with between-cluster covariates in clustered data
#'#-------------------------------------------------------------------------
#'res.perm.repeated <- permanovaFL(formula=sim.otu.tab5 | X.between ~ Y.between, 
#'                          data=sim.meta, dist.method="bray", seed=34794,
#'                          cluster.id=ID,                # parameters for requesting analysis of  
#'                          perm.within.type="none", perm.between.type="free") # repeated samples
#'                          
#'#-------------------------------------------------------------------------
#'# Testing associations with within-cluster covariates in matched-set data
#'#-------------------------------------------------------------------------
#'res.perm.matched <- permanovaFL(formula=sim.otu.tab5 | as.factor(ID) + X.within ~ Y.within, 
#'                          data=sim.meta, dist.method="bray", seed=34794,
#'                          cluster.id=ID,            # parameters for requesting analysis of  
#'                          perm.within.type="free", perm.between.type="none") # matched sets 








permanovaFL = function(formula, data=.GlobalEnv, tree=NULL, dist.method="bray",
                       cluster.id=NULL, strata=NULL, how=NULL,
                       perm.within.type="free", perm.between.type="none",
                       perm.within.ncol=0, perm.within.nrow=0,
                       n.perm.max=5000, n.rej.stop=100, seed=NULL,
                       square.dist=TRUE, center.dist=TRUE, scale.otu.table=TRUE, 
                       binary=FALSE, n.rarefy=0) {  
    
    #------------------------
    # form.call
    #------------------------
    options(na.action=na.omit) # fixed a bug here
    object=formula
    #
    #   extract cluster.id from dataframe
    #
    cl=match.call()
    mf=match.call(expand.dots=FALSE)
    m=match( x='cluster.id', table=names(mf) )
    mf.string=as.character( mf[c(1L,m)] )
    cluster.name=mf.string[2]
    if (cluster.name=='NULL') {
        cluster.id=NULL
    } else {   
        loc.dollar=tail( gregexpr('\\$', cluster.name)[[1]] , n=1 )
        if (loc.dollar<0)  {
            cluster.id=getElement(data,cluster.name)
            if( is.null(cluster.id) ) cluster.id=get(cluster.name)
        } else {   
            df.name=get( substr(cluster.name, start=1, stop=loc.dollar-1) )
            var.name=substr(cluster.name, start=loc.dollar+1, stop=nchar(cluster.name))            
            cluster.id= getElement(df.name,var.name) 
        }
    }
    #        
    #   extract model from formula    
    #    
    obj=toString(object)
    obj=gsub('\\s','',obj)
    prefix=' ~ + 0 + '
    loc.comma=gregexpr(',',obj)[[1]]
    start.terms=loc.comma[2]
    terms=substr(obj,start=start.terms+1, stop=nchar(obj))
    #
    #   find n.obs and full set of rownames
    #   
    if (class(data)=='data.frame') {
        row.names=rownames(data)
        n.obs=length(row.names)
    } else {   
        df=model.frame( paste('~',terms) , na.action=na.pass )
        row.names=rownames(df)
        n.obs=length(row.names)
    }
    #
    #   check for missing values in cluster.id
    #        
    
    if (is.null(cluster.id)) {
        use.rows=row.names
    } else {   
        use=!is.na(cluster.id)
        use.rows=row.names[use]
    }
    #
    #   check for and extract confounders
    #
    model=list()
    j=1
    loc.bar=regexpr('\\|',obj)[1]
    loc.minus=regexpr('-',obj)[1]
    loc.delim=max( loc.bar, loc.minus)
    if (loc.delim>0) {
        end.confound=loc.comma[2]
        c=substr(obj,start=loc.delim+1, stop=end.confound-1)
        conf=model.matrix( as.formula( paste(prefix,c) ), data=data ) 
        model[[j]]=model.matrix( as.formula( paste(prefix,c) ), data=data ) 
        #       use.rows=intersect( use.rows, rownames(conf) )
        use.rows=rownames(model[[1]]) 
        j=j+1
    } else {
        conf=NULL
    }     
    #
    #   extract model terms
    #
    #   j=1
    continue=TRUE
    while (continue) {
        if (substr(terms,1,1)=='(') {
            stop=regexpr(')\\+',terms)[1]
        } else {
            stop=regexpr('\\+',terms)[1] - 1
        }          
        
        if (stop<=0) stop=nchar(terms) 
        m=substr(terms, start=1, stop=stop)
        model[[j]]=model.matrix( as.formula( paste(prefix,m) ) , data=data)
        use.rows=intersect( use.rows, rownames(model[[j]]) )
        #        if (j==1) {
        #            use.rows=rownames(model[[1]])
        #            }
        #        else {
        #            use.rows=intersect( use.rows, rownames(model[[j]]) )
        #            }         
        if (stop+2<=nchar(terms)) {
            terms=substr(terms, start=stop+2, stop=nchar(terms))
            j=j+1
        } else {
            continue=FALSE
        }             
    }   
    n.model=j    
    #
    #  extract OTU table
    #      
    if (is.null(conf)) loc.delim=loc.comma[2]
    otu.name=substr(obj, start=loc.comma[1]+1, stop=loc.delim-1)
    #   loc.dollar=regexpr('\\$', otu.name)[1]
    loc.dollar=tail( gregexpr('\\$', otu.name)[[1]] , n=1 )
    if (loc.dollar<0)  {
        if (class(data)=='data.frame') {
            otu.table=getElement(data, otu.name)
            if (is.null(otu.table)) otu.table= get(otu.name) 
            otu.table=as.matrix(otu.table)
        } else {
            otu.table=as.matrix( get(otu.name) )
        }
    } else {
        df.name=get( substr(otu.name, start=1, stop=loc.dollar-1) )
        var.name=substr(otu.name, start=loc.dollar+1, stop=nchar(otu.name))
        otu.table=as.matrix( getElement(df.name,var.name) )
    }        
    #    if (is.null(otu.table)) otu.table=as.matrix( getElement(.GlobalEnv,otu.name) )
    if ( nrow(otu.table) != n.obs ) {
        if (ncol(otu.table)==n.obs ) {
            otu.table=t(otu.table)
        } else {   
            print('warning: OTU table and covariates have different number of observations')
            return
        }
    }   
    
    
    otu.or.dist <- as.matrix(otu.table)
    
    otu.table <- NULL
    dist <- NULL
    if (isSymmetric(otu.or.dist)) {
        dist <- otu.or.dist
    } else {
        otu.table <- otu.or.dist
    }
    
    #
    #   remove rows having NA 
    #    
    for (j in 1:n.model) {
        keep =  rownames( model[[j]] ) %in% use.rows
        model[[j]]=model[[j]][keep,,drop=FALSE]
    }
    if (!is.null(conf)) {
        keep =  rownames(conf) %in% use.rows 
        conf=conf[keep,,drop=FALSE]
    }
    keep=row.names %in% use.rows    
    if (!is.null(cluster.id)) cluster.id=cluster.id[keep]
    
    if (!is.null(dist)) {
        dist = dist[keep, keep]
        if (dim(model[[1]])[1] != dim(dist)[1]) stop( 'numbers of observations mismatch between covariates and the distance matrix' )
    }
    if (!is.null(otu.table)) {
        otu.table = otu.table[keep,,drop=FALSE]
        if (dim(model[[1]])[1] != dim(otu.table)[1]) 
            otu.table <- t(otu.table)
        if (dim(model[[1]])[1] != dim(otu.table)[1]) stop( 'numbers of observations mismatch between covariates and the OTU table' )
    }
    
    #------------------------
    # setup permutation
    #------------------------
    
    if (class(how)=='how') {
        CTRL=how                   # user-provided how list
    }
    else {
        if (is.null(cluster.id)) {
            if (is.null(perm.within.type) & is.null(perm.between.type)) {
                # default when no unclustered data has no type specified is 'free'
                perm.within.type='free'    
            }
            if (is.null(strata)) {
                 # setup for unclustered permutation
                CTRL = how( within=Within(type=perm.within.type, 
                                          nrow=perm.within.nrow, 
                                          ncol=perm.within.ncol))  
            }
            else {
                # setup for unclustered, stratified permutation
                strata=as.factor(strata)
                CTRL = how( blocks=strata, within=Within(type=perm.within.type, 
                                                         nrow=perm.within.nrow, 
                                                         ncol=perm.within.ncol))  
            }    
        }
        else {        
            cluster.id=as.factor(cluster.id)
            if (is.null(strata)) {            
                #  clustered but unstratified data
                CTRL = how( plots=Plots(cluster.id, type=perm.between.type ), 
                            within=Within(type=perm.within.type, 
                                          nrow=perm.within.nrow, 
                                          ncol=perm.within.ncol))
            }
            else {
                #   clustered and stratified data
                strata=as.factor(strata)             
                CTRL = how( blocks=strata, 
                            plots=Plots(cluster.id, type=perm.between.type ), 
                            within=Within(type=perm.within.type, 
                                          nrow=perm.within.nrow, 
                                          ncol=perm.within.ncol))
            }
        }
    }  
    
    
    #------------------------
    # decidinng methods
    #------------------------
    
    no_rarefy = (n.rarefy==0)
    if (no_rarefy) n.rarefy=1
    if (!is.null(dist)) n.rarefy=1
    
    if (binary) {
        scale.otu.table=FALSE
    }
    
    #------------------------
    # setup model
    #------------------------
    
    adjust.for.confounders = !is.null(conf)
    
    n.var = length(model)
    n.var1 = n.var - as.numeric(adjust.for.confounders)
    n.obs = dim(model[[1]])[1]
    
    center.vars=TRUE
    
    index = rep(0, n.var)
    
    for (i in 1:n.var) {
        m.i = model[[i]]
        if (center.vars) m.i = scale( m.i, center=TRUE, scale=FALSE )
        
        if (i==1) {
            m = m.i
            index[i] = dim(m.i)[2] 
        } else {
            m = cbind(m, m.i)   
            index[i] = index[i-1] + dim(m.i)[2]    
        }
        
    }    
    
    #---------------------
    # rarefaction or not?
    #---------------------
    
    resid.dist = array(NA, dim=c(n.obs, n.obs, n.var1, n.rarefy))
    
    if (is.null(seed)) {
        seed = sample(1:10^6, 1)
    }
    set.seed(seed)
    
    for (r in 1:n.rarefy) {
        
        if (!is.null(otu.table)) {
            if (!no_rarefy) {
                otu.rarefy= Rarefy(otu.table)$otu.tab.rff
                if (binary) otu.rarefy = (otu.rarefy>0)*1
            } else {
                if (binary) otu.rarefy = (otu.table>0)*1
                else otu.rarefy = otu.table
            }
        }
        
        #------------------------
        # dist matrix
        #------------------------
        
        if (is.null(dist)) {
            dist <- calculate.dist(dist.method=dist.method, otu.table=otu.rarefy, tree=tree, scale.otu.table=scale.otu.table, binary=binary)
            d.gower <- gower(d=dist, square=square.dist, center=center.dist)
            dist <- NULL
        } else {
            d.gower <- gower(d=dist, square=square.dist, center=center.dist)
        }
        
        #---------------------
        # model fitting
        #---------------------
    
        fit.res = fit.permanova( d.gower=d.gower, index=index, m=m, adjust.for.confounders=adjust.for.confounders) 
    
        resid.dist[,,,r] = fit.res$resid.dist
        
        if (r==1) {
            x = fit.res$x
            low = fit.res$low
            up = fit.res$up
            
            ndf = fit.res$ndf
        }
        
    }# rarefaction
    
    permanova.obs = permanova.stat(x=x, low=low, up=up, resid.dist=resid.dist, ndf=ndf, adjust.for.confounders=adjust.for.confounders)
    
    p.permanova = NULL
    n.perm.completed = NULL
    permanova.stopped = NULL
    
    #---------------------
    # permutation
    #---------------------
    
    if (n.perm.max > 0) {
        
        tol.eq = 10^-8
        n.perm.block = 1000
        
        n.permanova = 0
        n.perm.completed = 0
        
        set.seed(seed) # can be removed ???
        
        for (i.sim in 1:n.perm.max) {
            
            i.sim.r = i.sim%%n.perm.block
            if (i.sim.r==0) i.sim.r = n.perm.block
            
            if (i.sim.r==1) {
                cat("permutations:", i.sim, "\n")
                perm = shuffleSet(n.obs, n.perm.block, CTRL)
            }
            
            n.perm.completed = n.perm.completed + 1
            
            # perform permutations                   
            
            x.perm = fit.res$x[perm[i.sim.r,], ]   
            
            permanova.perm = permanova.stat(x=x.perm, low=low, up=up, resid.dist=resid.dist, ndf=ndf, adjust.for.confounders=adjust.for.confounders)
            
            n.permanova <- n.permanova + (permanova.perm$permanova > permanova.obs$permanova + tol.eq) + (permanova.perm$permanova > permanova.obs$permanova - tol.eq)
            
            if (all(n.permanova >= n.rej.stop*2)) break
            
        }# permutation
        
        permanova.stopped=all(n.permanova >= n.rej.stop*2)
        
        p.permanova <- ifelse((n.permanova >= n.rej.stop*2), 0.5*n.permanova*(1/n.perm.completed), (0.5*n.permanova+1)*(1/(n.perm.completed+1)))
        
    }# if (n.perm.max > 0)
    
    res = list( F.statistics=permanova.obs$permanova,
                p.permanova=p.permanova, 
                n.perm.completed=n.perm.completed, 
                permanova.stopped=permanova.stopped,
                seed=seed)
    return(res)
    
}# permanovaFL


fit.permanova = function( d.gower, index, m, adjust.for.confounders) {
    
    n.var = length(index)
    n.otu = ncol(d.gower)
    n.sam = nrow(d.gower)
    ndf.nominal = rep(0, n.var+1)
    
    tol.d = 10^-8
    
    #--------------------------------------------------------------------------
    # construct directions matrix x 
    # from each set of covariates in the list vars
    #--------------------------------------------------------------------------
    
    d.resid = d.gower
    
    for (i in 1:n.var) 
    {
        
        var = m[,1:index[i]]
        
        svd.var = svd(var)   
        use = (svd.var$d>tol.d)    
        
        hat.matrix = svd.var$u[, use] %*% t( svd.var$u[, use] )
        
        #---------------------
        # calculate direction
        #---------------------
        
        n.dim = dim( hat.matrix)[1]
        
        d.model = hat.matrix %*% d.resid
        d.model = d.model %*% hat.matrix
        
        es.model = eigen(d.model, symmetric=TRUE) # es: eigen system in Mathematica
        
        use = ( abs(es.model$values)>tol.d )
        ndf.model = sum( use )
        
        x.model = es.model$vectors[, use]
        e.model = es.model$values[use]
        
        hat.matrix.bar = diag(n.dim)  - hat.matrix
        d.resid = hat.matrix.bar %*% d.resid
        d.resid = d.resid %*% hat.matrix.bar
        
        #-----------------------------
        # end of calculating direction
        #-----------------------------    
        
        if (i==1) {
            x = x.model
            e = e.model
        } else {   
            x = cbind(x, x.model)
            e = c(e, e.model )
        }
        
        ndf.nominal[i] = ndf.model
        
    }
    
    es.resid = eigen(d.resid, symmetric=TRUE)
    use = which( abs(es.resid$values)>tol.d )
    
    ndf.nominal[n.var+1] = length(use)
    x = cbind(x, es.resid$vectors[, use])
    e = c(e, es.resid$values[use])
    
    #-------------------------------------------------
    # low, up
    #-------------------------------------------------
    
    low = rep(NA, n.var)
    up = rep(NA, n.var)
    
    up.prev = 0
    
    for (k in 1:n.var)
    {
        low[k] = up.prev + 1
        up[k] = up.prev + ndf.nominal[k]
        up.prev = up[k]
    }
    
    #---------------------
    # permanova: resid.dist
    #---------------------
    
    if (n.var==1) {
        resid.dist = array( NA, dim=c( dim(d.gower), n.var ) ) 
        resid.dist[,,1] = d.gower
    }
    else {
        n.var1 = ifelse(adjust.for.confounders, n.var-1, n.var)
        
        resid.dist = array( NA, dim=c( dim(d.gower), n.var1 ) ) 
        
        for (k in 1:n.var1) {
            k1 = ifelse(adjust.for.confounders, k+1, k)
            use = setdiff( 1:up[n.var], low[k1]:up[k1] )
            
            hat.matrix = x[,use,drop=FALSE] %*% t( x[,use,drop=FALSE] )
            hat.matrix.bar = diag(n.sam) - hat.matrix
            resid.dist[,,k] = hat.matrix.bar %*% d.gower 
            resid.dist[,,k] = resid.dist[,,k] %*% hat.matrix.bar
        }
    }
    
    
    res = list( x=x,
                low=low,
                up=up,
                resid.dist=resid.dist,
                ndf = ndf.nominal)
    return(res)
    
} # fit.permanova


permanova.stat = function(x, low, up, resid.dist, ndf, adjust.for.confounders) {
    
    #---------------------------------------------
    #  calculate FL statistics for each model
    #---------------------------------------------
    
    n.var = length(low)
    n.sam = nrow(x)
    n.rarefy = dim(resid.dist)[4]
    
    n.var1 = ifelse(adjust.for.confounders, n.var-1, n.var)
    
    permanova = matrix(0, n.var1, n.rarefy)
    
    for (r in 1:n.rarefy) {
        if (n.var==1) {
            
            use = 1:up[1]    
            H = x[, use] %*% t( x[, use] )
            I_H = diag(n.sam) - H
            
            permanova[1, r:n.rarefy] = permanova[1, r:n.rarefy] + sum( diag(H %*% resid.dist[,,1,r]) )/sum( diag(I_H %*% resid.dist[,,1,r]) ) # the other H and I_H is not needed
            
        }
        else {
            
            use = 1:up[n.var]
            Hcum = x[, use] %*% t( x[, use] )
            I_Hcum = diag(n.sam) - Hcum
            
            for (k in 1:n.var1) {
                
                k1 = k + as.numeric(adjust.for.confounders)
                
                use = low[k1]:up[k1]
                Hk = x[, use] %*% t( x[, use] )
                
                permanova[k, r:n.rarefy] = permanova[k, r:n.rarefy] + sum( diag(Hk %*% resid.dist[,,k,r]) )/sum( diag(I_Hcum %*% resid.dist[,,k,r]) ) # the other Hk and I_Hcum is not needed
            }
        }   
    }
    
    var = ifelse(adjust.for.confounders, 2:n.var, 1:n.var)
    out = list( permanova=permanova * ndf[n.var+1] / ndf[var]) 
    
    return(out)
    
} # permanova.stat


#################################
# Expectation of distance matrix
#################################

#' Expected value of the Jaccard distance matrix
#' 
#' This function computes the expected value of the Jaccard distance matrix over rarefaction replicates.
#' 
#' @param otu.table the \code{n.obs} by \code{n.otu} matrix of read counts. 
#' @param rarefy.depth rarefaction depth. The default is the minimum library size observed in the OTU table.
#' @param first.order.approx.only a logical value indicating whether to calculate the expected value 
#' using the first order approixmation by the delta method. 
#' The default is FALSE, using the second order approixmation.
#' @return a list consisting of 
#'   \item{jac.mean.o1}{Expected Jaccard distance matrix by the first order approixmation.}
#'   \item{jac.mean.o2}{Expected Jaccard distance matrix by the second order approixmation.} 
#'   \item{jac.mean.sq.o1}{Expected squared Jaccard distance matrix by the first order approixmation.} 
#'   \item{jac.mean.sq.o2}{Expected squared Jaccard distance matrix by the second order approixmation.} 
#' @keywords microbiome
#' @author Yi-Juan Hu <yijuan.hu@emory.edu>, Glen A. Satten <gsatten@emory.edu>
#' @export
#' @examples
#' res.jaccard <- jaccard.mean( throat.otu.tab5 )

jaccard.mean = function( otu.table, rarefy.depth=min(rowSums(otu.table)), first.order.approx.only=FALSE) {
    if (!first.order.approx.only) {
        out = jaccard.mean.o1o2(otu.table, rarefy.depth)
    }
    else {
        res = jaccard.mean.o1(otu.table, rarefy.depth)
        out=list( jac.mean.o1=res$jac.mean.1, 
                  jac.mean.o2=NA, 
                  jac.mean.sq.o1=res$jac.mean.1^2, 
                  jac.mean.sq.o2=NA)
    }
    return(out)
}

# (old) jaccard.mean.fast
jaccard.mean.o1o2 = function( otu.table, rarefy.depth=min(rowSums(otu.table)) ) {
    otu.table=as.matrix(otu.table)
    n.obs=dim(otu.table)[1]
    n.taxa=dim(otu.table)[2]
    n.elem=n.taxa*(n.taxa-1)/2
    m.elem=max( rowSums( ifelse(otu.table>0,1,0) ) )
    index.mu=matrix(0,nrow=n.obs, ncol=m.elem)
    n.index.mu=rep(0,n.obs)
    m.elem=m.elem*(m.elem-1)/2
    #
    #	calculate mu, and mu.dot
    #
    d=matrix(0, nrow=n.obs, ncol=n.elem)
    n.i=rowSums( otu.table )
    l.denom=lchoose(n.i, rarefy.depth)
    jac.sq=diag(n.obs)
    mu=matrix(0,nrow=n.obs, ncol=n.taxa)
    mu.dot=rep(0,n.obs)
    for (i in 1:n.obs) {
        use=which( otu.table[i,]>0 )
        l.pr=lchoose( n.i[i] - otu.table[i,use], rarefy.depth ) - l.denom[i]
        mu[i,use]=1 - exp(l.pr)
        #		mu[i,use]=1 - choose( n.i[i] - otu.table[i,use], rarefy.depth)/denom[i]
        mu.dot[i]=sum( mu[i,use] )
        n.index.mu[i]=length(use)
        index.mu[i, 1:n.index.mu[i] ]=use
    }
    #
    #	calculate d, psi.11 and psi.12
    #		
    psi.11=psi.12=psi.21=matrix(0, nrow=n.obs, ncol=n.obs)
    psi.22=matrix(0, nrow=n.obs, ncol=n.obs)
    index.d=matrix(0, nrow=n.obs, ncol=m.elem)
    n.index.d=rep(0,n.obs)
    for (i in 1:n.obs) {
        use=which( otu.table[i,]>0 )
        n.use=length(use)
        k.1=use[rep( 1:(n.use-1), times=(n.use-1):1 )]
        k.2=use[unlist(sapply(2:n.use, FUN = function(x){x:n.use}))]
        k=n.taxa*(k.1-1) + k.2 - k.1*(k.1 + 1)/2
        ln.pr=lchoose( n.i[i] - otu.table[i,k.1] - otu.table[i,k.2], rarefy.depth ) - l.denom[i]
        d[i,k]=exp(ln.pr) + mu[i,k.1] + mu[i,k.2] - 1
        #		
        cs.1=colSums( t(mu[,k.1])*d[i,k] )
        cs.2=colSums( t(mu[,k.2])*d[i,k] )
        cs.d=sum( d[i,k] )
        #		
        psi.11[i,]=cs.d -   cs.1 -   cs.2
        psi.12[i,]=cs.d -   cs.1 - 2*cs.2
        psi.21[i,]=cs.d - 2*cs.1 -   cs.2
        psi.22[i,]=cs.d - 2*cs.1 - 2*cs.2
        #		
        n.index.d[i]=n.use*(n.use-1)/2
        index.d[i,1:n.index.d[i]]=k
        
        # psi.11[i,]=colSums( t(1-mu[,k.1]-mu[,k.2]) * d[i,k] )
        # psi.12[i,]=colSums( t(1-mu[,k.1]-2*mu[,k.2]) * d[i,k] )
        # psi.21[i,]=colSums( t(1-2*mu[,k.1]-mu[,k.2]) * d[i,k] )
        # psi.22[i,]=colSums( t(1-2*mu[,k.1]-2*mu[,k.2]) * d[i,k] )
    }
    #
    #	calculate 2nd order approximation to average jaccard 
    #	
    jac.mean.1=jac.mean.2=matrix(0, nrow=n.obs, ncol=n.obs)
    jac.mean.sq.1=jac.mean.sq.2=matrix(0, nrow=n.obs, ncol=n.obs)
    jac.sq.ave=u22=u11=u12=matrix(0, nrow=n.obs, ncol=n.obs)
    for (i in 1:(n.obs-1)) {
        for (j in (i+1):n.obs) {
            #			use=which( otu.table[i,]*otu.table[j,]>0 )
            use=intersect( index.mu[i,1:n.index.mu[i]], index.mu[j,1:n.index.mu[j]] )
            dot.product.mu=sum( mu[i,use]*mu[j,use] )
            use=intersect( index.d[i,1:n.index.d[i]], index.d[j, 1:n.index.d[j]] )
            dot.product.d=sum( d[i,use]*d[j,use] )
            e.1=mu.dot[i]+mu.dot[j]-dot.product.mu
            e.2=e.1 - dot.product.mu
            u.11=mu.dot[i] + mu.dot[j] + 2*mu.dot[i]*mu.dot[j] - 3*dot.product.mu + 2*(psi.11[i,j]+psi.11[j,i]) + 2*dot.product.d
            u.12=mu.dot[i] + mu.dot[j] + 2*mu.dot[i]*mu.dot[j] - 4*dot.product.mu + (psi.12[i,j]+psi.12[j,i]+psi.21[i,j]+psi.21[j,i]) + 4*dot.product.d
            u.22=mu.dot[i] + mu.dot[j] + 2*mu.dot[i]*mu.dot[j] - 4*dot.product.mu + 2*(psi.22[i,j]+psi.22[j,i]) + 8*dot.product.d
            jac.mean.1[i,j]=e.2/e.1
            jac.mean.2[i,j]=jac.mean.1[i,j] + (u.11*e.2 - u.12*e.1)/(e.1^3)
            jac.mean.sq.1[i,j]=jac.mean.1[i,j]^2
            jac.mean.sq.2[i,j]=jac.mean.sq.1[i,j] + (u.22*e.1^2-4*u.12*e.1*e.2+3*u.11*e.2^2)/(e.1^4)
            jac.sq.ave[i,j]=u.22/u.11
            u11[i,j]=u.11
            u22[i,j]=u.22
            u12[i,j]=u.12
        }
    }	
    jac.mean.1=jac.mean.1 + t(jac.mean.1)
    jac.mean.2=jac.mean.2 + t(jac.mean.2)
    jac.mean.sq.1=jac.mean.sq.1 + t(jac.mean.sq.1)
    jac.mean.sq.2=jac.mean.sq.2 + t(jac.mean.sq.2)
    jac.sq.ave=jac.sq.ave + t(jac.sq.ave)	
    u11=u11 + t(u11)
    u22=u22 + t(u22)
    u12=u12 + t(u12)
    
    res=list( jac.mean.o1=jac.mean.1, 
              jac.mean.o2=jac.mean.2, 
              jac.mean.sq.o1=jac.mean.sq.1, 
              jac.mean.sq.o2=jac.mean.sq.2)
    return(res)
    
} # jaccard.mean.fast


#(old) jaccard.ave.1
jaccard.mean.o1 = function( otu.table, rarefy.depth=min(rowSums(otu.table)) ) {
    #
    #	calculates only the zeroth order (first term) of the jaccard mean 
    #
    otu.table=as.matrix(otu.table)
    n.obs=dim(otu.table)[1]
    n.taxa=dim(otu.table)[2]
    n.elem=n.taxa*(n.taxa-1)/2
    m.elem=max( rowSums( ifelse(otu.table>0,1,0) ) )
    index.mu=matrix(0,nrow=n.obs, ncol=m.elem)
    n.index.mu=rep(0,n.obs)
    m.elem=m.elem*(m.elem-1)/2
    #
    #	calculate mu, and mu.dot
    #
    n.i=rowSums( otu.table )
    l.denom=lchoose(n.i, rarefy.depth)
    mu=matrix(0,nrow=n.obs, ncol=n.taxa)
    mu.dot=rep(0,n.obs)
    for (i in 1:n.obs) {
        use=which( otu.table[i,]>0 )
        l.pr=lchoose( n.i[i] - otu.table[i,use], rarefy.depth ) - l.denom[i]
        mu[i,use]=1 - exp(l.pr)
        #		mu[i,use]=1 - choose( n.i[i] - otu.table[i,use], rarefy.depth)/denom[i]
        mu.dot[i]=sum( mu[i,use] )
        n.index.mu[i]=length(use)
        index.mu[i, 1:n.index.mu[i] ]=use
    }
    #
    #	calculate 2nd order approximation to average jaccard 
    #	
    jac.mean.1=e1=e2=matrix(0, nrow=n.obs, ncol=n.obs)
    for (i in 1:(n.obs-1)) {
        for (j in (i+1):n.obs) {
            use=intersect( index.mu[i,1:n.index.mu[i]], index.mu[j,1:n.index.mu[j]] )
            dot.product.mu=sum( mu[i,use]*mu[j,use] )
            e.1=mu.dot[i]+mu.dot[j]-dot.product.mu
            e.2=e.1 - dot.product.mu
            jac.mean.1[i,j]=e.2/e.1
            e1[i,j]=e.1
            e2[i,j]=e.2
        }
    }	
    jac.mean.1=jac.mean.1 + t(jac.mean.1)
    e1=e1 + t(e1)
    e2=e2 + t(e2)
    
    res=list( jac.mean.o1=jac.mean.1)
    return(res)
    
} # jaccard.ave.1



#' Expected value of the unweighted UniFrac distance matrix
#' 
#' This function computes the expected value of the unweighted UniFrac distance matrix over rarefaction replicates.
#' 
#' @param otu.table the \code{n.obs} by \code{n.otu} matrix of read counts. 
#' @param tree the phylogeneic tree.
#' @param rarefy.depth rarefaction depth. The default is the minimum library size observed in the OTU table.
#' @param first.order.approx.only a logical value indicating whether to calculate the expected value 
#' using the first order approixmation by the delta method. The default is FALSE, 
#' using the second order approixmation.
#' @return a list consisting of 
#'   \item{unifrac.mean.o1}{Expected unweighted UniFrac distance matrix by the first order approixmation.}
#'   \item{unifrac.mean.o2}{Expected unweighted UniFrac distance matrix by the second order approixmation.} 
#'   \item{unifrac.mean.sq.o1}{Expected squared unweighted UniFrac distance matrix by the first order approixmation.} 
#'   \item{unifrac.mean.sq.o2}{Expected squared unweighted UniFrac distance matrix by the second order approixmation.} 
#' @keywords microbiome
#' @author Yi-Juan Hu <yijuan.hu@emory.edu>, Glen A. Satten <gsatten@emory.edu>
#' @export
#' @examples
#' res.unifrac <- unifrac.mean( throat.otu.tab5, throat.tree)

unifrac.mean = function( otu.table, tree, rarefy.depth=min(rowSums(otu.table)), first.order.approx.only=FALSE) {
    if (!first.order.approx.only) {
        out = unifrac.mean.o2o1(otu.table, tree, rarefy.depth)
    }
    else {
        res = unifrac.mean.o1(otu.table, tree, rarefy.depth)
        out=list( unifrac.mean.o1=res$unifrac.mean.1, 
                  unifrac.mean.o2=NA, 
                  unifrac.mean.sq.o1=res$unifrac.mean.1^2, 
                  unifrac.mean.sq.o2=NA)
    }
    return(out)
}

`%notin%` <- Negate(`%in%`)

#(old) unifrac.ave.sq.fast
unifrac.mean.o1o2 = function( otu.table, tree, rarefy.depth=min(rowSums(otu.table)), trim=TRUE, keep.root=TRUE) {
    
    require('ips')
    require('castor')
    require('phangorn')
    
    otu.table=as.matrix(otu.table)
    n.obs=dim(otu.table)[1]
    n.taxa=dim(otu.table)[2]                # note for later:  remove cols with zero colSums?
    #	
    #
    #	sort OTU table to agree with ordering of tips in tree
    #
    tree.names=tree$tip.label
    otu.names=colnames(otu.table)
    #
    #	if trim=TRUE remove any taxa that do not appear in OTU table and then prune tree accordingly
    #
    if (trim==TRUE) {
        keep=which(colSums( otu.table )>0)
        if (sum(keep)<n.taxa) {
            print('number of empty taxa dropped from OTU table:')
            print( n.taxa-sum(keep) )
            otu.table=otu.table[,keep]
            n.taxa=dim(otu.table)[2]
            otu.names=colnames(otu.table)
        }
        if (length(tree.names)<length(otu.names)) {
            print('error: there are more taxa in OTU table than tree')
            return
        }
        else if (length(tree.names)>length(otu.names)) {
            drop.names=setdiff( tree.names, otu.names )
            drop.list=which( tree.names %in% drop.names)
            tree=get_subtree_with_tips(tree,omit_tips=drop.list, force_keep_root=keep.root)$subtree
            #			tree=drop.tip(tree,drop.list,collapse.singles=!keep.root)
            tree.names=tree$tip.label
            otu.table=otu.table[,tree.names]
            print('number of tips dropped from tree:')
            print( length(drop.list) )
        }
    }	
    if( !all(sort(tree.names)==sort(otu.names)) ) {
        print('taxa names in tree and OTU table to not agree')
        return
    }
    otu.table=otu.table[,tree.names]
    #
    #	set up branch lengths
    #	
    edge.2=tree$edge[,2]
    n.internal=max(edge.2) - n.taxa - 1
    n.branch=length(edge.2)
    n.node=n.taxa + n.internal
    n.elem=n.node*(n.node-1)/2
    edge.2=tree$edge[,2]
    tips=which( edge.2<=n.taxa )
    nodes=which( edge.2>n.taxa+1)
    #	edge.2[tips]=edge.2[tips]+n.taxa-2
    edge.2[tips]=edge.2[tips]+n.internal
    edge.2[nodes]=edge.2[nodes]-n.taxa-1
    ord=order(edge.2)
    edge.2=edge.2[ord]
    br.length=tree$edge.length[ord]
    #
    #	set up list of descendants for each node (nodes  1:(n.internal) are internal nodes; nodes (n.internal):(n.internal+n.taxa-1) are tips)
    #	
    #	descendants=allDescendants(tree)
    descendants=Descendants(tree,node=c((n.taxa+2):(n.taxa+1+n.internal), 1:n.taxa), type='tips')
    # k.1=rep( 1:(n.node-1), times=(n.node-1):1 )
    # k.2=unlist(sapply(2:n.node, FUN = function(x){x:n.node}))
    # k=n.node*(k.1-1) + k.2 - k.1*(k.1+1)/2
    ancestry=matrix(FALSE,nrow=n.taxa, ncol=n.node)
    for (k in 1:n.node) {
        ancestry[ descendants[[k]], k]=TRUE
    }
    
    #
    #	set up list of tips and internal nodes of ancestors for each observation; calculate mu, mu.bar and mu.bar.2
    #	
    tips.i=list()
    #	nodes.i=list()
    all.nodes.i=list()
    mu=mu.bar=mu.bar.2=matrix(0,nrow=n.obs, ncol=n.node)
    mu.dot.1=rep(0,n.obs)
    mu.dot.2=rep(0,n.obs)
    n.i=rowSums( otu.table )
    l.denom=lchoose(n.i, rarefy.depth)
    for (i in 1:n.obs) {
        tips=which( otu.table[i,]>0 )
        nodes=sort( unique( unlist( Ancestors(x=tree, node=tips, type='all') ) ) ) - n.taxa - 1 
        nodes=nodes[nodes>0]
        all.nodes=union(nodes,tips+n.internal)
        tips.i=append(tips.i, list(tips) )
        all.nodes.i=append(all.nodes.i, list( all.nodes ))
        n.nodes=length(all.nodes)
        #		use.k=lapply( descendants[all.nodes], FUN=function(x) intersect(x,tips) )
        #		c.sum.k=unlist( lapply( use.k, FUN=function(x) sum( otu.table[i,x] ) ) )
        c.sum.k=colSums( otu.table[i,tips]*ancestry[tips,all.nodes] )
        mu.bar[i,all.nodes]=exp( lchoose( n.i[i]-c.sum.k, rarefy.depth ) - l.denom[i] )
        mu[i,all.nodes]=1-mu.bar[i,all.nodes]
        mu.bar.2[i,all.nodes]=1-mu.bar[i,all.nodes]
        mu.dot.1[i]=sum( mu[i,all.nodes]*br.length[all.nodes] )
        mu.dot.2[i]=sum( mu[i,all.nodes]*br.length[all.nodes]^2 )
    }
    #
    #   calculate d, psi.11, psi.12 and psi.22
    #	
    d=matrix(0,nrow=n.obs, ncol=n.elem)
    psi.11=psi.12=psi.21=matrix(0, nrow=n.obs, ncol=n.obs)
    psi.22=matrix(0, nrow=n.obs, ncol=n.obs)
    
    
    for (i in 1:n.obs) {
        all.nodes=all.nodes.i[[i]]
        tips=tips.i[[i]]
        n.nodes=length(all.nodes)
        k.1=all.nodes[rep( 1:(n.nodes-1), times=(n.nodes-1):1 )]
        k.2=all.nodes[unlist(sapply(2:n.nodes, FUN = function(x){x:n.nodes}))]
        k=n.node*(k.1-1) + k.2 - k.1*(k.1+1)/2
        #		c.sum.k1.k2=mapply( descendants[k.1], descendants[k.2], FUN=function(x,y) sum( otu.table[i,intersect( union(x,y),tips )]), SIMPLIFY=TRUE)  #this is slower than loop that follows
        #		n.k=length(k)
        #		c.sum.k1.k2=rep(0, n.k)
        #		for (j in 1:n.k) {
        #			c.sum.k1.k2[j]=sum( otu.table[i, intersect( union( descendants[[k.1[j]]], descendants[[k.2[j]]] ), tips) ] )
        #			}
        
        c.sum.k1.k2=colSums( otu.table[i,tips]*(ancestry[tips,k.1] | ancestry[tips,k.2]) )
        
        
        d[i,k]=exp( lchoose( n.i[i]-c.sum.k1.k2, rarefy.depth ) - l.denom[i] ) + mu[i,k.1] + mu[i,k.2] - 1
        #		
        cs.1=colSums( t(mu[,k.1])*d[i,k]*br.length[k.1]*br.length[k.2] )
        cs.2=colSums( t(mu[,k.2])*d[i,k]*br.length[k.1]*br.length[k.2] )
        cs.d=sum( d[i,k]*br.length[k.1]*br.length[k.2] )
        #		
        psi.11[i,]=cs.d -   cs.1 -   cs.2
        psi.12[i,]=cs.d -   cs.1 - 2*cs.2
        psi.21[i,]=cs.d - 2*cs.1 -   cs.2
        psi.22[i,]=cs.d - 2*cs.1 - 2*cs.2
        #		
    }	
    #
    #	calculate 2nd order approximation to average unifrac
    #	
    unifrac.mean.1=unifrac.mean.2=matrix(0, nrow=n.obs, ncol=n.obs)
    unifrac.mean.sq.1=unifrac.mean.sq.2=unifrac.sq.ave=matrix(0, nrow=n.obs, ncol=n.obs)
    u11=u12=u22=e1=e2=matrix(0,nrow=n.obs, ncol=n.obs)
    #
    k.index=rep( 1:(n.node-1), times=(n.node-1):1 )
    k1.index=unlist(sapply(2:n.node, FUN = function(x){x:n.node}))
    #
    for (i in 1:(n.obs-1)) {
        for (j in (i+1):n.obs) {
            use=which( mu[i,]*mu[j,]>0 )
            dot.product.mu.1=sum( mu[i,use]*mu[j,use]*br.length[use] )
            dot.product.mu.2=sum( mu[i,use]*mu[j,use]*br.length[use]^2 )
            use=which( d[i,]*d[j,]>0 )
            k.node=k.index[use]
            k1.node=k1.index[use]
            dot.product.d=sum( d[i,use]*d[j,use]*br.length[k.node]*br.length[k1.node] )
            e.1=mu.dot.1[i]+mu.dot.1[j]-dot.product.mu.1
            e.2=e.1 - dot.product.mu.1
            u.11=mu.dot.2[i] + mu.dot.2[j] + 2*mu.dot.1[i]*mu.dot.1[j] - 3*dot.product.mu.2 + 2*(psi.11[i,j]+psi.11[j,i]) + 2*dot.product.d
            u.12=mu.dot.2[i] + mu.dot.2[j] + 2*mu.dot.1[i]*mu.dot.1[j] - 4*dot.product.mu.2 + (psi.12[i,j]+psi.12[j,i]+psi.21[i,j]+psi.21[j,i]) + 4*dot.product.d
            u.22=mu.dot.2[i] + mu.dot.2[j] + 2*mu.dot.1[i]*mu.dot.1[j] - 4*dot.product.mu.2 + 2*(psi.22[i,j]+psi.22[j,i]) + 8*dot.product.d
            unifrac.mean.1[i,j]=e.2/e.1
            unifrac.mean.2[i,j]=unifrac.mean.1[i,j] + (u.11*e.2 - u.12*e.1)/(e.1^3)
            unifrac.mean.sq.1[i,j]=unifrac.mean.1[i,j]^2
            unifrac.mean.sq.2[i,j]=unifrac.mean.sq.1[i,j] + (u.22*e.1^2-4*u.12*e.1*e.2+3*u.11*e.2^2)/(e.1^4)
            unifrac.sq.ave[i,j]=u.22/u.11
            u11[i,j]=u.11
            u12[i,j]=u.12
            u22[i,j]=u.22
            e1[i,j]=e.1
            e2[i,j]=e.2
        }
    }	
    unifrac.mean.1=unifrac.mean.1 + t(unifrac.mean.1)
    unifrac.mean.2=unifrac.mean.2 + t(unifrac.mean.2)
    unifrac.mean.sq.1=unifrac.mean.sq.1 + t(unifrac.mean.sq.1)
    unifrac.mean.sq.2=unifrac.mean.sq.2 + t(unifrac.mean.sq.2)
    unifrac.sq.ave=unifrac.sq.ave + t(unifrac.sq.ave)	
    
    u11=u11 + t(u11)
    u12=u12 + t(u12)
    u22=u22 + t(u22)
    e1=e1 + t(e1)
    e2=e2 + t(e2)
    
    res=list( unifrac.mean.o1=unifrac.mean.1, 
              unifrac.mean.o2=unifrac.mean.2, 
              unifrac.mean.sq.o1=unifrac.mean.sq.1, 
              unifrac.mean.sq.o2=unifrac.mean.sq.2)
    return(res)
    
} #unifrac.ave.sq.fast

# (old) unifrac.ave.1
unifrac.mean.o1 = function( otu.table, tree, rarefy.depth=min(rowSums(otu.table)), trim=TRUE, keep.root=TRUE) {
    #
    #	calculates only the zeroth order (first) term for the unifrac distance
    #
    require('ips')
    require('castor')
    require('phangorn')
    otu.table=as.matrix(otu.table)
    n.obs=dim(otu.table)[1]
    n.taxa=dim(otu.table)[2]                
    if (trim==TRUE) {	
        #
        #		remove zero columns from OTU table
        #		
        keep.list=which( colSums(otu.table)>0 )
        otu.table=otu.table[,keep.list]
        print( c('note: empty taxa removed, number of taxa changed from',n.taxa,'to',length(keep.list) ) )
        n.taxa=dim(otu.table)[2]
    }
    #	
    #
    #	harmonize lists of taxa from tree, OTU table and then sort OTU table to agree with ordering of tips in tree
    #
    tree.names=tree$tip.label
    otu.names=colnames(otu.table)
    n.tree.names=length(tree.names)
    n.otu.names=length(otu.names)
    if (n.otu.names<n.tree.names) {
        #
        #		remove tree nodes that do not correspond to taxa in otu.table
        #	
        drop.list=which( tree.names %notin% otu.names )
        tree=get_subtree_with_tips(tree,omit_tips=drop.list, force_keep_root=keep.root)$subtree
        tree.names=tree$tip.label
        print( c('note: number of nodes in tree reduced from', n.tree.names, 'to', length(tree.names) ), quote=FALSE)
    }
    if( !all(sort(tree.names)==sort(otu.names)) ) {
        #
        #		remove otus that are not in tree
        #	
        keep.list=which( otu.names %in% tree.names )
        otu.table=otu.table[,keep.list]
        n.taxa=dim(otu.table)[2]
        print( c('note: number of taxa in OTU table reduced from', n.otu.names, 'to', n.taxa), quote=FALSE )
    }
    otu.table=otu.table[,tree.names]
    #
    #	set up branch lengths
    #	
    edge.2=tree$edge[,2]
    n.internal=max(edge.2) - n.taxa - 1
    n.branch=length(edge.2)
    n.node=n.taxa + n.internal
    n.elem=n.node*(n.node-1)/2
    edge.2=tree$edge[,2]
    tips=which( edge.2<=n.taxa )
    nodes=which( edge.2>n.taxa+1)
    #	edge.2[tips]=edge.2[tips]+n.taxa-2
    edge.2[tips]=edge.2[tips]+n.internal
    edge.2[nodes]=edge.2[nodes]-n.taxa-1
    ord=order(edge.2)
    edge.2=edge.2[ord]
    br.length=tree$edge.length[ord]
    #
    #	set up list of descendants for each node (nodes  1:(n.internal) are internal nodes; nodes (n.internal):(n.internal+n.taxa-1) are tips)
    #	
    #	descendants=allDescendants(tree)
    descendants=Descendants(tree,node=c((n.taxa+2):(n.taxa+1+n.internal), 1:n.taxa), type='tips')
    # k.1=rep( 1:(n.node-1), times=(n.node-1):1 )
    # k.2=unlist(sapply(2:n.node, FUN = function(x){x:n.node}))
    # k=n.node*(k.1-1) + k.2 - k.1*(k.1+1)/2
    ancestry=matrix(FALSE,nrow=n.taxa, ncol=n.node)
    for (k in 1:n.node) {
        ancestry[ descendants[[k]], k]=TRUE
    }
    
    #
    #	set up list of tips and internal nodes of ancestors for each observation; calculate mu, mu.bar and mu.bar.2
    #	
    mu=matrix(0,nrow=n.obs, ncol=n.node)
    n.i=rowSums( otu.table )
    l.denom=lchoose(n.i, rarefy.depth)
    mu.dot.1=rep(0,n.obs)
    for (i in 1:n.obs) {
        tips=which( otu.table[i,]>0 )
        nodes=sort( unique( unlist( Ancestors(x=tree, node=tips, type='all') ) ) ) - n.taxa - 1 
        nodes=nodes[nodes>0]
        all.nodes=union(nodes,tips+n.internal)
        #		use.k=lapply( descendants[all.nodes], FUN=function(x) intersect(x,tips) )
        #		c.sum.k=unlist( lapply( use.k, FUN=function(x) sum( otu.table[i,x] ) ) )
        c.sum.k=colSums( otu.table[i,tips]*ancestry[tips,all.nodes] )
        mu[i,all.nodes]=1- exp( lchoose( n.i[i]-c.sum.k, rarefy.depth ) - l.denom[i] )
        mu.dot.1[i]=sum( mu[i,all.nodes]*br.length[all.nodes] )
    }
    
    #		
    unifrac.mean.1=e1=e2=matrix(0, nrow=n.obs, ncol=n.obs)
    #
    for (i in 1:(n.obs-1)) {
        for (j in (i+1):n.obs) {
            use=which( mu[i,]*mu[j,]>0 )
            dot.product.mu.1=sum( mu[i,use]*mu[j,use]*br.length[use] )
            e.1=mu.dot.1[i]+mu.dot.1[j]-dot.product.mu.1
            e.2=e.1 - dot.product.mu.1
            unifrac.mean.1[i,j]=e.2/e.1
            e1[i,j]=e.1
            e2[i,j]=e.2
        }
    }	
    unifrac.mean.1=unifrac.mean.1 + t(unifrac.mean.1)
    
    e1=e1 + t(e1)
    e2=e2 + t(e2)
    
    res=list( unifrac.mean.o1=unifrac.mean.1)
    return(res)
    
} # unifrac.ave.1


#####################################################################
# no use (memory efficient version)
#####################################################################

jaccard.mean.fast.small = function( otu.table, rarefy.depth=min(rowSums(otu.table)) ) {
    otu.table=as.matrix(otu.table)
    n.obs=dim(otu.table)[1]
    n.taxa=dim(otu.table)[2]
    n.elem=n.taxa*(n.taxa-1)/2
    m.elem=max( rowSums( ifelse(otu.table>0,1,0) ) )
    index.mu=matrix(0,nrow=n.obs, ncol=m.elem)
    n.index.mu=rep(0,n.obs)
    m.elem=m.elem*(m.elem-1)/2
    #
    #	calculate mu, and mu.dot
    #
    n.i=rowSums( otu.table )
    l.denom=lchoose(n.i, rarefy.depth)
    jac.sq=diag(n.obs)
    mu=matrix(0,nrow=n.obs, ncol=n.taxa)
    mu.dot=rep(0,n.obs)
    for (i in 1:n.obs) {
        use=which( otu.table[i,]>0 )
        l.pr=lchoose( n.i[i] - otu.table[i,use], rarefy.depth ) - l.denom[i]
        mu[i,use]=1 - exp(l.pr)
        #		mu[i,use]=1 - choose( n.i[i] - otu.table[i,use], rarefy.depth)/denom[i]
        mu.dot[i]=sum( mu[i,use] )
        n.index.mu[i]=length(use)
        index.mu[i, 1:n.index.mu[i] ]=use
    }
    #
    #	calculate d, psi.11 and psi.12
    #
    max.taxa=max( rowSums( ifelse(otu.table>0,1,0) ) )
    n.elem.d=max.taxa*(max.taxa-1)/2
    psi.11=psi.12=psi.21=matrix(0, nrow=n.obs, ncol=n.obs)
    psi.22=matrix(0, nrow=n.obs, ncol=n.obs)
    d=matrix(0, nrow=n.obs, ncol=n.elem.d)
    index.d=matrix(0, nrow=n.obs, ncol=n.elem.d)
    n.index.d=rep(0,n.obs)
    for (i in 1:n.obs) {
        use=which( otu.table[i,]>0 )
        n.use=length(use)
        k.1=use[rep( 1:(n.use-1), times=(n.use-1):1 )]
        k.2=use[unlist(sapply(2:n.use, FUN = function(x){x:n.use}))]
        k=n.taxa*(k.1-1) + k.2 - k.1*(k.1 + 1)/2
        ln.pr=lchoose( n.i[i] - otu.table[i,k.1] - otu.table[i,k.2], rarefy.depth ) - l.denom[i]
        n.index.d[i]=n.use*(n.use-1)/2
        index.d[i,1:n.index.d[i]]=k
        d[i,1:n.index.d[i]]=exp(ln.pr) + mu[i,k.1] + mu[i,k.2] - 1
        #		
        cs.1=colSums( t(mu[,k.1])*d[i,1:n.index.d[i]] )
        cs.2=colSums( t(mu[,k.2])*d[i,1:n.index.d[i]] )
        cs.d=sum( d[i,1:n.index.d[i]] )
        #		
        psi.11[i,]=cs.d -   cs.1 -   cs.2
        psi.12[i,]=cs.d -   cs.1 - 2*cs.2
        psi.21[i,]=cs.d - 2*cs.1 -   cs.2
        psi.22[i,]=cs.d - 2*cs.1 - 2*cs.2
        #		
        
        # psi.11[i,]=colSums( t(1-mu[,k.1]-mu[,k.2]) * d[i,k] )
        # psi.12[i,]=colSums( t(1-mu[,k.1]-2*mu[,k.2]) * d[i,k] )
        # psi.21[i,]=colSums( t(1-2*mu[,k.1]-mu[,k.2]) * d[i,k] )
        # psi.22[i,]=colSums( t(1-2*mu[,k.1]-2*mu[,k.2]) * d[i,k] )
    }
    #
    #	calculate 2nd order approximation to average jaccard 
    #	
    jac.ave.1=jac.ave.2=matrix(0, nrow=n.obs, ncol=n.obs)
    jac.ave.sq.1=jac.ave.sq.2=matrix(0, nrow=n.obs, ncol=n.obs)
    jac.sq.ave=u22=u11=u12=matrix(0, nrow=n.obs, ncol=n.obs)
    for (i in 1:(n.obs-1)) {
        for (j in (i+1):n.obs) {
            #			use=which( otu.table[i,]*otu.table[j,]>0 )
            use=intersect( index.mu[i,1:n.index.mu[i]], index.mu[j,1:n.index.mu[j]] )
            dot.product.mu=sum( mu[i,use]*mu[j,use] )
            # 			use=intersect( index.d[i,1:n.index.d[i]], index.d[j, 1:n.index.d[j]] )
            use.i=which( index.d[i,1:n.index.d[i]] %in% index.d[j,1:n.index.d[j]] )
            use.j=which( index.d[j,1:n.index.d[j]] %in% index.d[i,1:n.index.d[i]] )
            dot.product.d=sum( d[i,use.i]*d[j,use.j] )
            e.1=mu.dot[i]+mu.dot[j]-dot.product.mu
            e.2=e.1 - dot.product.mu
            u.11=mu.dot[i] + mu.dot[j] + 2*mu.dot[i]*mu.dot[j] - 3*dot.product.mu + 2*(psi.11[i,j]+psi.11[j,i]) + 2*dot.product.d
            u.12=mu.dot[i] + mu.dot[j] + 2*mu.dot[i]*mu.dot[j] - 4*dot.product.mu + (psi.12[i,j]+psi.12[j,i]+psi.21[i,j]+psi.21[j,i]) + 4*dot.product.d
            u.22=mu.dot[i] + mu.dot[j] + 2*mu.dot[i]*mu.dot[j] - 4*dot.product.mu + 2*(psi.22[i,j]+psi.22[j,i]) + 8*dot.product.d
            jac.ave.1[i,j]=e.2/e.1
            jac.ave.2[i,j]=jac.ave.1[i,j] + (u.11*e.2 - u.12*e.1)/(e.1^3)
            jac.ave.sq.1[i,j]=jac.ave.1[i,j]^2
            jac.ave.sq.2[i,j]=jac.ave.sq.1[i,j] + (u.22*e.1^2-4*u.12*e.1*e.2+3*u.11*e.2^2)/(e.1^4)
            jac.sq.ave[i,j]=u.22/u.11
            u11[i,j]=u.11
            u22[i,j]=u.22
            u12[i,j]=u.12
        }
    }	
    jac.ave.1=jac.ave.1 + t(jac.ave.1)
    jac.ave.2=jac.ave.2 + t(jac.ave.2)
    jac.ave.sq.1=jac.ave.sq.1 + t(jac.ave.sq.1)
    jac.ave.sq.2=jac.ave.sq.2 + t(jac.ave.sq.2)
    jac.sq.ave=jac.sq.ave + t(jac.sq.ave)	
    u11=u11 + t(u11)
    u22=u22 + t(u22)
    u12=u12 + t(u12)
    
    res=list( jac.ave.1=jac.ave.1, 
              jac.ave.2=jac.ave.2, 
              jac.ave.sq.1=jac.ave.sq.1, 
              jac.ave.sq.2=jac.ave.sq.2)
    return(res)
    
} #jaccard.mean.fast.small

unifrac.ave.sq.fast.small = function( otu.table, tree, rarefy.depth=min(rowSums(otu.table)), trim=FALSE, keep.root=TRUE, n.batch=1) {
    require('ips')
    require('castor')
    require('phangorn')
    
    otu.table=as.matrix(otu.table)
    n.obs=dim(otu.table)[1]
    n.taxa=dim(otu.table)[2]                
    if (trim==TRUE) {	
        #
        #		remove zero columns from OTU table
        #		
        keep.list=which( colSums(otu.table)>0 )
        otu.table=otu.table[,keep.list]
        print( c('note: empty taxa removed, number of taxa changed from',n.taxa,'to',length(keep.list) ) )
        n.taxa=dim(otu.table)[2]
    }
    #	
    #
    #	harmonize lists of taxa from tree, OTU table and then sort OTU table to agree with ordering of tips in tree
    #
    tree.names=tree$tip.label
    otu.names=colnames(otu.table)
    n.tree.names=length(tree.names)
    n.otu.names=length(otu.names)
    if (n.otu.names<n.tree.names) {
        #
        #		remove tree nodes that do not correspond to taxa in otu.table
        #	
        drop.list=which( tree.names %notin% otu.names )
        tree=get_subtree_with_tips(tree,omit_tips=drop.list, force_keep_root=keep.root)$subtree
        tree.names=tree$tip.label
        print( c('note: number of nodes in tree reduced from', n.tree.names, 'to', length(tree.names) ), quote=FALSE)
    }
    if( !all(sort(tree.names)==sort(otu.names)) ) {
        #
        #		remove otus that are not in tree
        #	
        keep.list=which( otu.names %in% tree.names )
        otu.table=otu.table[,keep.list]
        n.taxa=dim(otu.table)[2]
        print( c('note: number of taxa in OTU table reduced from', n.otu.names, 'to', n.taxa), quote=FALSE )
    }
    otu.table=otu.table[,tree.names]
    #
    #	set up branch lengths
    #	
    edge.2=tree$edge[,2]
    n.internal=max(edge.2) - n.taxa - 1
    n.branch=length(edge.2)
    n.node=n.taxa + n.internal
    n.elem=n.node*(n.node-1)/2
    edge.2=tree$edge[,2]
    tips=which( edge.2<=n.taxa )
    nodes=which( edge.2>n.taxa+1)
    #	edge.2[tips]=edge.2[tips]+n.taxa-2
    edge.2[tips]=edge.2[tips]+n.internal
    edge.2[nodes]=edge.2[nodes]-n.taxa-1
    ord=order(edge.2)
    edge.2=edge.2[ord]
    br.length=tree$edge.length[ord]
    #
    #	set up list of descendants for each node (nodes  1:(n.internal) are internal nodes; nodes (n.internal):(n.internal+n.taxa-1) are tips)
    #	
    #	descendants=allDescendants(tree)
    descendants=Descendants(tree,node=c((n.taxa+2):(n.taxa+1+n.internal), 1:n.taxa), type='tips')
    # k.1=rep( 1:(n.node-1), times=(n.node-1):1 )
    # k.2=unlist(sapply(2:n.node, FUN = function(x){x:n.node}))
    # k=n.node*(k.1-1) + k.2 - k.1*(k.1+1)/2
    ancestry=matrix(FALSE,nrow=n.taxa, ncol=n.node)
    for (k in 1:n.node) {
        ancestry[ descendants[[k]], k]=TRUE
    }
    
    #
    #	set up list of tips and internal nodes of ancestors for each observation; calculate mu, mu.bar and mu.bar.2
    #	
    tips.i=list()
    #	nodes.i=list()
    all.nodes.i=list()
    mu=mu.bar=mu.bar.2=matrix(0,nrow=n.obs, ncol=n.node)
    mu.dot.1=rep(0,n.obs)
    mu.dot.2=rep(0,n.obs)
    n.i=rowSums( otu.table )
    l.denom=lchoose(n.i, rarefy.depth)
    n.nodes.max=0
    for (i in 1:n.obs) {
        tips=which( otu.table[i,]>0 )
        nodes=sort( unique( unlist( Ancestors(x=tree, node=tips, type='all') ) ) ) - n.taxa - 1 
        nodes=nodes[nodes>0]
        all.nodes=union(nodes,tips+n.internal)
        tips.i=append(tips.i, list(tips) )
        all.nodes.i=append(all.nodes.i, list( all.nodes ))
        n.nodes=length(all.nodes)
        n.nodes.max=max(n.nodes.max, n.nodes)
        #		use.k=lapply( descendants[all.nodes], FUN=function(x) intersect(x,tips) )
        #		c.sum.k=unlist( lapply( use.k, FUN=function(x) sum( otu.table[i,x] ) ) )
        c.sum.k=colSums( otu.table[i,tips]*ancestry[tips,all.nodes] )
        mu.bar[i,all.nodes]=exp( lchoose( n.i[i]-c.sum.k, rarefy.depth ) - l.denom[i] )
        mu[i,all.nodes]=1-mu.bar[i,all.nodes]
        mu.bar.2[i,all.nodes]=1-mu.bar[i,all.nodes]
        mu.dot.1[i]=sum( mu[i,all.nodes]*br.length[all.nodes] )
        mu.dot.2[i]=sum( mu[i,all.nodes]*br.length[all.nodes]^2 )
    }
    #
    #   calculate d, psi.11, psi.12 and psi.22
    #	
    n.max.elem=n.nodes.max*(n.nodes.max-1)/2
    #	d=matrix(0,nrow=n.obs, ncol=n.max.elem)
    d=list()
    #	index.d=matrix(0, nrow=n.obs, ncol=n.max.elem)
    index.d=list()
    n.index.d=rep(0,n.obs)
    psi.11=psi.12=psi.21=matrix(0, nrow=n.obs, ncol=n.obs)
    psi.22=matrix(0, nrow=n.obs, ncol=n.obs)
    
    
    for (i in 1:n.obs) {
        all.nodes=all.nodes.i[[i]]
        tips=tips.i[[i]]
        n.nodes=length(all.nodes)
        k.1=all.nodes[rep( 1:(n.nodes-1), times=(n.nodes-1):1 )]
        k.2=all.nodes[unlist(sapply(2:n.nodes, FUN = function(x){x:n.nodes}))]
        k=n.node*(k.1-1) + k.2 - k.1*(k.1+1)/2
        
        #		c.sum.k1.k2=mapply( descendants[k.1], descendants[k.2], FUN=function(x,y) sum( otu.table[i,intersect( union(x,y),tips )]), SIMPLIFY=TRUE)  #this is slower than loop that follows
        #		n.k=length(k)
        #		c.sum.k1.k2=rep(0, n.k)
        #		for (j in 1:n.k) {
        #			c.sum.k1.k2[j]=sum( otu.table[i, intersect( union( descendants[[k.1[j]]], descendants[[k.2[j]]] ), tips) ] )
        #			}
        
        if (n.batch>1) {
            n.tips=length(tips)
            use.batch=batch( n.tips, n.batch )
            n.batch.use=length(use.batch)
            tips.use=tips[ use.batch[[1]] ]
            c.sum.k1.k2=colSums( otu.table[i, tips.use]*(ancestry[tips.use, k.1, drop=FALSE] | ancestry[tips.use, k.2, drop=FALSE]) )
            for (nb in 2:n.batch.use) {
                tips.use=tips[ use.batch[[nb]] ]
                c.sum.k1.k2=c.sum.k1.k2+colSums( otu.table[i, tips.use]*(ancestry[tips.use, k.1, drop=FALSE] | ancestry[tips.use, k.2, drop=FALSE]) )
            }
        }	
        else {	
            c.sum.k1.k2=colSums( otu.table[i,tips]*(ancestry[tips,k.1] | ancestry[tips,k.2]) )
        }
        
        n.index.d[i]=n.nodes*(n.nodes-1)/2
        #		index.d[i,1:n.index.d[i]]=k
        index.d=c(index.d,list(k))
        
        #		d[i,1:n.index.d[i]]=exp( lchoose( n.i[i]-c.sum.k1.k2, rarefy.depth ) - l.denom[i] ) + mu[i,k.1] + mu[i,k.2] - 1
        d=c(d, list(exp( lchoose( n.i[i]-c.sum.k1.k2, rarefy.depth ) - l.denom[i] ) + mu[i,k.1] + mu[i,k.2] - 1 ) )
        #		
        #		cs.1=colSums( t(mu[,k.1])*d[i,1:n.index.d[i]]*br.length[k.1]*br.length[k.2] )
        #		cs.2=colSums( t(mu[,k.2])*d[i,1:n.index.d[i]]*br.length[k.1]*br.length[k.2] )
        #		cs.d=sum( d[i,1:n.index.d[i]]*br.length[k.1]*br.length[k.2] )
        cs.1=colSums( t(mu[,k.1])*d[[i]]*br.length[k.1]*br.length[k.2] )
        cs.2=colSums( t(mu[,k.2])*d[[i]]*br.length[k.1]*br.length[k.2] )
        cs.d=sum( d[[i]]*br.length[k.1]*br.length[k.2] )
        #		
        psi.11[i,]=cs.d -   cs.1 -   cs.2
        psi.12[i,]=cs.d -   cs.1 - 2*cs.2
        psi.21[i,]=cs.d - 2*cs.1 -   cs.2
        psi.22[i,]=cs.d - 2*cs.1 - 2*cs.2
        #		
    }	
    #
    #	calculate 2nd order approximation to average unifrac
    #	
    unifrac.ave.1=unifrac.ave.2=matrix(0, nrow=n.obs, ncol=n.obs)
    unifrac.ave.sq.1=unifrac.ave.sq.2=unifrac.sq.ave=matrix(0, nrow=n.obs, ncol=n.obs)
    u11=u12=u22=e1=e2=matrix(0,nrow=n.obs, ncol=n.obs)
    #
    k.index=rep( 1:(n.node-1), times=(n.node-1):1 )
    k1.index=unlist(sapply(2:n.node, FUN = function(x){x:n.node}))
    #
    for (i in 1:(n.obs-1)) {
        for (j in (i+1):n.obs) {
            use=which( mu[i,]*mu[j,]>0 )
            dot.product.mu.1=sum( mu[i,use]*mu[j,use]*br.length[use] )
            dot.product.mu.2=sum( mu[i,use]*mu[j,use]*br.length[use]^2 )
            #			use=intersect( index.d[i,1:n.index.d[i]], index.d[j,1:n.index.d[j]] )
            #			use.i=which( index.d[i,1:n.index.d[i]] %in% use )
            #			use.j=which( index.d[j,1:n.index.d[j]] %in% use )
            use=intersect( index.d[[i]], index.d[[j]] )
            use.i=which( index.d[[i]] %in% use )
            use.j=which( index.d[[j]] %in% use )
            k.node=k.index[use]
            k1.node=k1.index[use]
            # 			dot.product.d=sum( d[i,use.i]*d[j,use.j]*br.length[k.node]*br.length[k1.node] )
            dot.product.d=sum( (d[[i]][use.i])*(d[[j]][use.j])*br.length[k.node]*br.length[k1.node] )
            e.1=mu.dot.1[i]+mu.dot.1[j]-dot.product.mu.1
            e.2=e.1 - dot.product.mu.1
            u.11=mu.dot.2[i] + mu.dot.2[j] + 2*mu.dot.1[i]*mu.dot.1[j] - 3*dot.product.mu.2 + 2*(psi.11[i,j]+psi.11[j,i]) + 2*dot.product.d
            u.12=mu.dot.2[i] + mu.dot.2[j] + 2*mu.dot.1[i]*mu.dot.1[j] - 4*dot.product.mu.2 + (psi.12[i,j]+psi.12[j,i]+psi.21[i,j]+psi.21[j,i]) + 4*dot.product.d
            u.22=mu.dot.2[i] + mu.dot.2[j] + 2*mu.dot.1[i]*mu.dot.1[j] - 4*dot.product.mu.2 + 2*(psi.22[i,j]+psi.22[j,i]) + 8*dot.product.d
            unifrac.ave.1[i,j]=e.2/e.1
            unifrac.ave.2[i,j]=unifrac.ave.1[i,j] + (u.11*e.2 - u.12*e.1)/(e.1^3)
            unifrac.ave.sq.1[i,j]=unifrac.ave.1[i,j]^2
            unifrac.ave.sq.2[i,j]=unifrac.ave.sq.1[i,j] + (u.22*e.1^2-4*u.12*e.1*e.2+3*u.11*e.2^2)/(e.1^4)
            unifrac.sq.ave[i,j]=u.22/u.11
            u11[i,j]=u.11
            u12[i,j]=u.12
            u22[i,j]=u.22
            e1[i,j]=e.1
            e2[i,j]=e.2
        }
    }	
    unifrac.ave.1=unifrac.ave.1 + t(unifrac.ave.1)
    unifrac.ave.2=unifrac.ave.2 + t(unifrac.ave.2)
    unifrac.ave.sq.1=unifrac.ave.sq.1 + t(unifrac.ave.sq.1)
    unifrac.ave.sq.2=unifrac.ave.sq.2 + t(unifrac.ave.sq.2)
    unifrac.sq.ave=unifrac.sq.ave + t(unifrac.sq.ave)	
    
    u11=u11 + t(u11)
    u12=u12 + t(u12)
    u22=u22 + t(u22)
    e1=e1 + t(e1)
    e2=e2 + t(e2)
    
    res=list( unifrac.ave.1=unifrac.ave.1, 
              unifrac.ave.2=unifrac.ave.2, 
              unifrac.ave.sq.1=unifrac.ave.sq.1, 
              unifrac.ave.sq.2=unifrac.ave.sq.2, 
              unifrac.sq.ave=unifrac.sq.ave)
    return(res)
    
} # unifrac.ave.sq.fast.small



batch = function( n, n.batch ) {
    max.num=floor( n/n.batch )
    x=seq(n)
    levels=floor(x/max.num)
    x.split=split(x, factor(levels))
    return(x.split)
}









